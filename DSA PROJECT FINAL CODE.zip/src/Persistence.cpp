#include "../include/Persistence.h"
#include <fstream>
#include <string>

namespace
{
bool splitLine(const std::string& line, std::string fields[], int maximumFields, int& fieldCount)
{
	fieldCount = 0;
	int fieldStart = 0;
	for (int i = 0; i <= static_cast<int>(line.length()); ++i)
	{
		if (i == static_cast<int>(line.length()) || line[i] == '|')
		{
			if (fieldCount >= maximumFields)
			{
				return false;
			}

			fields[fieldCount] = line.substr(fieldStart, i - fieldStart);
			++fieldCount;
			fieldStart = i + 1;
		}
	}

	return true;
}

Household* firstHousehold(const HouseholdHashTable& householdTable)
{
	for (int i = 0; i < HOUSEHOLD_HASH_SIZE; ++i)
	{
		HouseholdHashNode* current = householdTable.buckets[i];
		if (current != nullptr)
		{
			return current->household;
		}
	}

	return nullptr;
}

bool ensureGraphVertex(FamilyGraph& graph, const std::string& residentID)
{
	if (findFamilyGraphNode(graph, residentID) != nullptr)
	{
		return true;
	}

	return addResidentVertex(graph, residentID);
}

bool loadFailure(HouseholdHashTable& householdTable, ResidentHashTable& residentTable, FamilyGraph& graph)
{
	clearApplicationData(householdTable, residentTable, graph);
	return false;
}
}

void clearApplicationData(HouseholdHashTable& householdTable, ResidentHashTable& residentTable, FamilyGraph& graph)
{
	Household* household = firstHousehold(householdTable);
	while (household != nullptr)
	{
		std::string householdID = household->householdID;
		clearHouseholdResidents(*household, residentTable);
		removeHouseholdFromHashTable(householdTable, householdID);
		delete household;
		household = firstHousehold(householdTable);
	}

	destroyResidentHashTable(residentTable);
	destroyHouseholdHashTable(householdTable);
	destroyFamilyGraph(graph);
}

bool saveToTextFile(const char* fileName, const HouseholdHashTable& householdTable, const FamilyGraph& graph)
{
	if (fileName == nullptr)
	{
		return false;
	}

	std::ofstream outputFile(fileName);
	if (!outputFile.is_open())
	{
		return false;
	}

	for (int i = 0; i < HOUSEHOLD_HASH_SIZE; ++i)
	{
		HouseholdHashNode* householdHashNode = householdTable.buckets[i];
		while (householdHashNode != nullptr)
		{
			Household* household = householdHashNode->household;
			outputFile << "HOUSEHOLD|" << household->householdID << '|'
				<< household->cityID << '|' << household->subCityID << '|'
				<< household->woredaID << '|' << household->address << '\n';

			for (int eventIndex = 0; eventIndex < household->eventCount; ++eventIndex)
			{
				const CivilEvent& event = household->events[eventIndex];
				outputFile << "EVENT|" << event.eventID << '|'
					<< event.eventType << '|' << event.eventDate << '|'
					<< event.notes << '\n';
			}

			for (int documentIndex = 0; documentIndex < household->documentCount; ++documentIndex)
			{
				const Document& document = household->documents[documentIndex];
				outputFile << "DOCUMENT|" << document.documentID << '|'
					<< document.documentType << '|' << document.issueDate << '|'
					<< document.status << '\n';
			}

			ResidentNode* residentNode = household->residentHead;
			while (residentNode != nullptr)
			{
				const Resident& resident = residentNode->data;
				outputFile << "RESIDENT|" << resident.residentID << '|'
					<< resident.fullName << '|' << resident.dateOfBirth << '|'
					<< resident.gender << '\n';

				ResidenceHistoryNode* historyNode = resident.historyHead;
				while (historyNode != nullptr)
				{
					outputFile << "HISTORY|" << historyNode->householdID << '|'
						<< historyNode->startDate << '|' << historyNode->endDate << '|'
						<< historyNode->notes << '\n';
					historyNode = historyNode->next;
				}

				outputFile << "END_RESIDENT\n";
				residentNode = residentNode->next;
			}

			outputFile << "END_HOUSEHOLD\n";
			householdHashNode = householdHashNode->next;
		}
	}

	FamilyGraphNode* graphNode = graph.head;
	while (graphNode != nullptr)
	{
		outputFile << "VERTEX|" << graphNode->residentID << '\n';
		graphNode = graphNode->next;
	}

	graphNode = graph.head;
	while (graphNode != nullptr)
	{
		RelationshipNode* relationship = graphNode->relationshipHead;
		while (relationship != nullptr)
		{
			outputFile << "RELATION|" << graphNode->residentID << '|'
				<< relationship->relatedResidentID << '|'
				<< relationship->relationshipType << '\n';
			relationship = relationship->next;
		}
		graphNode = graphNode->next;
	}

	return outputFile.good();
}

bool loadFromTextFile(const char* fileName, HouseholdHashTable& householdTable, ResidentHashTable& residentTable, FamilyGraph& graph)
{
	if (fileName == nullptr)
	{
		return false;
	}

	std::ifstream inputFile(fileName);
	if (!inputFile.is_open())
	{
		return false;
	}

	clearApplicationData(householdTable, residentTable, graph);
	initializeHouseholdHashTable(householdTable);
	initializeResidentHashTable(residentTable);
	initializeFamilyGraph(graph);

	Household* currentHousehold = nullptr;
	ResidentNode* currentResident = nullptr;
	std::string line;
	while (std::getline(inputFile, line))
	{
		if (line.empty())
		{
			continue;
		}

		std::string fields[6];
		int fieldCount = 0;
		if (!splitLine(line, fields, 6, fieldCount) || fieldCount == 0)
		{
			return loadFailure(householdTable, residentTable, graph);
		}

		if (fields[0] == "HOUSEHOLD")
		{
			if (fieldCount != 6 || currentHousehold != nullptr)
			{
				return loadFailure(householdTable, residentTable, graph);
			}

			Household* newHousehold = new Household;
			initializeHousehold(*newHousehold, fields[1], fields[2], fields[3], fields[4], fields[5]);
			if (!insertHousehold(householdTable, newHousehold))
			{
				delete newHousehold;
				return loadFailure(householdTable, residentTable, graph);
			}
			currentHousehold = newHousehold;
		}
		else if (fields[0] == "EVENT")
		{
			if (currentHousehold == nullptr || fieldCount != 5 || currentHousehold->eventCount >= MAX_CIVIL_EVENTS)
			{
				return loadFailure(householdTable, residentTable, graph);
			}

			CivilEvent& event = currentHousehold->events[currentHousehold->eventCount];
			event.eventID = fields[1];
			event.eventType = fields[2];
			event.eventDate = fields[3];
			event.notes = fields[4];
			++currentHousehold->eventCount;
		}
		else if (fields[0] == "DOCUMENT")
		{
			if (currentHousehold == nullptr || fieldCount != 5 || currentHousehold->documentCount >= MAX_DOCUMENTS)
			{
				return loadFailure(householdTable, residentTable, graph);
			}

			Document& document = currentHousehold->documents[currentHousehold->documentCount];
			document.documentID = fields[1];
			document.documentType = fields[2];
			document.issueDate = fields[3];
			document.status = fields[4];
			++currentHousehold->documentCount;
		}
		else if (fields[0] == "RESIDENT")
		{
			if (currentHousehold == nullptr || currentResident != nullptr || fieldCount != 5)
			{
				return loadFailure(householdTable, residentTable, graph);
			}

			if (!addResident(*currentHousehold, residentTable, fields[1], fields[2], fields[3], fields[4]))
			{
				return loadFailure(householdTable, residentTable, graph);
			}
			currentResident = findResidentByID(residentTable, fields[1]);
			if (currentResident == nullptr || !ensureGraphVertex(graph, fields[1]))
			{
				return loadFailure(householdTable, residentTable, graph);
			}
		}
		else if (fields[0] == "HISTORY")
		{
			if (currentResident == nullptr || fieldCount != 5)
			{
				return loadFailure(householdTable, residentTable, graph);
			}

			appendResidenceHistory(currentResident->data.historyHead, currentResident->data.historyTail, fields[1], fields[2], fields[3], fields[4]);
		}
		else if (fields[0] == "END_RESIDENT")
		{
			if (fieldCount != 1 || currentResident == nullptr)
			{
				return loadFailure(householdTable, residentTable, graph);
			}
			currentResident = nullptr;
		}
		else if (fields[0] == "END_HOUSEHOLD")
		{
			if (fieldCount != 1 || currentHousehold == nullptr || currentResident != nullptr)
			{
				return loadFailure(householdTable, residentTable, graph);
			}
			currentHousehold = nullptr;
		}
		else if (fields[0] == "VERTEX")
		{
			if (fieldCount != 2 || currentHousehold != nullptr ||
				findResidentByID(residentTable, fields[1]) == nullptr || !ensureGraphVertex(graph, fields[1]))
			{
				return loadFailure(householdTable, residentTable, graph);
			}
		}
		else if (fields[0] == "RELATION")
		{
			if (fieldCount != 4 || currentHousehold != nullptr ||
				findResidentByID(residentTable, fields[1]) == nullptr ||
				findResidentByID(residentTable, fields[2]) == nullptr ||
				!relationshipExists(graph, fields[1], fields[2], fields[3]) &&
				!addRelationship(graph, fields[1], fields[2], fields[3], false))
			{
				return loadFailure(householdTable, residentTable, graph);
			}
		}
		else
		{
			return loadFailure(householdTable, residentTable, graph);
		}
	}

	if (currentHousehold != nullptr || currentResident != nullptr)
	{
		return loadFailure(householdTable, residentTable, graph);
	}

	return true;
}
