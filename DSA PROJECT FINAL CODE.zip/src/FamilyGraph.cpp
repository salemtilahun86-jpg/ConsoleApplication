#include "../include/FamilyGraph.h"
#include <iostream>

namespace
{
FamilyGraphNode* findGraphNode(const FamilyGraph& graph, const std::string& residentID)
{
	FamilyGraphNode* current = graph.head;
	while (current != nullptr)
	{
		if (current->residentID == residentID)
		{
			return current;
		}
		current = current->next;
	}

	return nullptr;
}

bool addDirectedRelationship(FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType)
{
	FamilyGraphNode* fromNode = findGraphNode(graph, fromResidentID);
	FamilyGraphNode* toNode = findGraphNode(graph, toResidentID);
	if (fromNode == nullptr || toNode == nullptr || relationshipExists(graph, fromResidentID, toResidentID, relationshipType))
	{
		return false;
	}

	RelationshipNode* newRelationship = new RelationshipNode;
	newRelationship->relatedResidentID = toResidentID;
	newRelationship->relationshipType = relationshipType;
	newRelationship->next = fromNode->relationshipHead;
	fromNode->relationshipHead = newRelationship;
	return true;
}

bool removeDirectedRelationship(FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType)
{
	FamilyGraphNode* fromNode = findGraphNode(graph, fromResidentID);
	if (fromNode == nullptr)
	{
		return false;
	}

	RelationshipNode* current = fromNode->relationshipHead;
	RelationshipNode* previous = nullptr;
	while (current != nullptr)
	{
		if (current->relatedResidentID == toResidentID && current->relationshipType == relationshipType)
		{
			if (previous == nullptr)
			{
				fromNode->relationshipHead = current->next;
			}
			else
			{
				previous->next = current->next;
			}

			delete current;
			return true;
		}

		previous = current;
		current = current->next;
	}

	return false;
}

bool wasVisited(const std::string& residentID, std::string visitedResidentIDs[], int visitedCount)
{
	for (int i = 0; i < visitedCount; ++i)
	{
		if (visitedResidentIDs[i] == residentID)
		{
			return true;
		}
	}

	return false;
}

void dfsRecursive(FamilyGraph& graph, const std::string& residentID, std::string visitedResidentIDs[], int& visitedCount, int maxVisited)
{
	if (visitedCount >= maxVisited || wasVisited(residentID, visitedResidentIDs, visitedCount))
	{
		return;
	}

	FamilyGraphNode* graphNode = findGraphNode(graph, residentID);
	if (graphNode == nullptr)
	{
		return;
	}

	visitedResidentIDs[visitedCount] = residentID;
	++visitedCount;
	std::cout << residentID << " ";

	RelationshipNode* relationship = graphNode->relationshipHead;
	while (relationship != nullptr)
	{
		dfsRecursive(graph, relationship->relatedResidentID, visitedResidentIDs, visitedCount, maxVisited);
		relationship = relationship->next;
	}
}
}

void initializeFamilyGraph(FamilyGraph& graph)
{
	graph.head = nullptr;
}

FamilyGraphNode* findFamilyGraphNode(FamilyGraph& graph, const std::string& residentID)
{
	return findGraphNode(graph, residentID);
}

bool addResidentVertex(FamilyGraph& graph, const std::string& residentID)
{
	if (findGraphNode(graph, residentID) != nullptr)
	{
		return false;
	}

	FamilyGraphNode* newNode = new FamilyGraphNode;
	newNode->residentID = residentID;
	newNode->relationshipHead = nullptr;
	newNode->next = graph.head;
	graph.head = newNode;
	return true;
}

bool removeResidentVertex(FamilyGraph& graph, const std::string& residentID)
{
	FamilyGraphNode* targetNode = findGraphNode(graph, residentID);
	if (targetNode == nullptr)
	{
		return false;
	}

	FamilyGraphNode* currentGraphNode = graph.head;
	while (currentGraphNode != nullptr)
	{
		RelationshipNode* currentRelationship = currentGraphNode->relationshipHead;
		RelationshipNode* previousRelationship = nullptr;
		while (currentRelationship != nullptr)
		{
			RelationshipNode* nextRelationship = currentRelationship->next;
			if (currentGraphNode != targetNode && currentRelationship->relatedResidentID == residentID)
			{
				if (previousRelationship == nullptr)
				{
					currentGraphNode->relationshipHead = nextRelationship;
				}
				else
				{
					previousRelationship->next = nextRelationship;
				}
				delete currentRelationship;
			}
			else
			{
				previousRelationship = currentRelationship;
			}
			currentRelationship = nextRelationship;
		}
		currentGraphNode = currentGraphNode->next;
	}

	FamilyGraphNode* previousGraphNode = nullptr;
	currentGraphNode = graph.head;
	while (currentGraphNode != targetNode)
	{
		previousGraphNode = currentGraphNode;
		currentGraphNode = currentGraphNode->next;
	}

	if (previousGraphNode == nullptr)
	{
		graph.head = targetNode->next;
	}
	else
	{
		previousGraphNode->next = targetNode->next;
	}

	RelationshipNode* targetRelationship = targetNode->relationshipHead;
	while (targetRelationship != nullptr)
	{
		RelationshipNode* nextRelationship = targetRelationship->next;
		delete targetRelationship;
		targetRelationship = nextRelationship;
	}
	delete targetNode;
	return true;
}

bool relationshipExists(const FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType)
{
	FamilyGraphNode* fromNode = findGraphNode(graph, fromResidentID);
	if (fromNode == nullptr)
	{
		return false;
	}

	RelationshipNode* current = fromNode->relationshipHead;
	while (current != nullptr)
	{
		if (current->relatedResidentID == toResidentID && current->relationshipType == relationshipType)
		{
			return true;
		}
		current = current->next;
	}

	return false;
}

bool addRelationship(FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType, bool bidirectional)
{
	bool forwardExists = relationshipExists(graph, fromResidentID, toResidentID, relationshipType);
	bool reverseExists = relationshipExists(graph, toResidentID, fromResidentID, relationshipType);
	if (forwardExists)
	{
		if (bidirectional && fromResidentID != toResidentID && !reverseExists)
		{
			return addDirectedRelationship(graph, toResidentID, fromResidentID, relationshipType);
		}
		return false;
	}

	if (!addDirectedRelationship(graph, fromResidentID, toResidentID, relationshipType))
	{
		return false;
	}

	if (bidirectional && fromResidentID != toResidentID)
	{
		if (!reverseExists &&
			!addDirectedRelationship(graph, toResidentID, fromResidentID, relationshipType))
		{
			removeDirectedRelationship(graph, fromResidentID, toResidentID, relationshipType);
			return false;
		}
	}

	return true;
}

bool removeRelationship(FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType, bool bidirectional)
{
	bool forwardExists = relationshipExists(graph, fromResidentID, toResidentID, relationshipType);
	bool reverseExists = relationshipExists(graph, toResidentID, fromResidentID, relationshipType);
	if (!forwardExists)
	{
		if (bidirectional && fromResidentID != toResidentID && reverseExists)
		{
			return removeDirectedRelationship(graph, toResidentID, fromResidentID, relationshipType);
		}
		return false;
	}

	if (!removeDirectedRelationship(graph, fromResidentID, toResidentID, relationshipType))
	{
		return false;
	}

	if (bidirectional && fromResidentID != toResidentID)
	{
		if (reverseExists &&
			!removeDirectedRelationship(graph, toResidentID, fromResidentID, relationshipType))
		{
			addDirectedRelationship(graph, fromResidentID, toResidentID, relationshipType);
			return false;
		}
	}

	return true;
}

void displayRelationships(const FamilyGraph& graph, const std::string& residentID)
{
	FamilyGraphNode* graphNode = findGraphNode(graph, residentID);
	if (graphNode == nullptr)
	{
		std::cout << "Resident vertex not found: " << residentID << "\n";
		return;
	}

	std::cout << "Relationships for " << residentID << ":\n";
	RelationshipNode* current = graphNode->relationshipHead;
	while (current != nullptr)
	{
		std::cout << "  " << residentID << " -> " << current->relatedResidentID
			<< " (" << current->relationshipType << ")\n";
		current = current->next;
	}
}

void displayFamilyGraph(const FamilyGraph& graph)
{
	std::cout << "Family graph:\n";
	FamilyGraphNode* current = graph.head;
	while (current != nullptr)
	{
		displayRelationships(graph, current->residentID);
		current = current->next;
	}
}

int dfs(FamilyGraph& graph, const std::string& startResidentID, std::string visitedResidentIDs[], int maxVisited)
{
	if (visitedResidentIDs == nullptr || maxVisited <= 0 || findGraphNode(graph, startResidentID) == nullptr)
	{
		return 0;
	}

	int visitedCount = 0;
	std::cout << "DFS from " << startResidentID << ": ";
	dfsRecursive(graph, startResidentID, visitedResidentIDs, visitedCount, maxVisited);
	std::cout << "\n";
	return visitedCount;
}

void displayDFS(FamilyGraph& graph, const std::string& startResidentID)
{
	int vertexCount = 0;
	FamilyGraphNode* current = graph.head;
	while (current != nullptr)
	{
		++vertexCount;
		current = current->next;
	}

	if (vertexCount == 0)
	{
		std::cout << "DFS cannot start because the graph is empty.\n";
		return;
	}

	std::string* visitedResidentIDs = new std::string[vertexCount];
	dfs(graph, startResidentID, visitedResidentIDs, vertexCount);
	delete[] visitedResidentIDs;
}

void destroyFamilyGraph(FamilyGraph& graph)
{
	FamilyGraphNode* currentGraphNode = graph.head;
	while (currentGraphNode != nullptr)
	{
		RelationshipNode* currentRelationship = currentGraphNode->relationshipHead;
		while (currentRelationship != nullptr)
		{
			RelationshipNode* nextRelationship = currentRelationship->next;
			delete currentRelationship;
			currentRelationship = nextRelationship;
		}

		FamilyGraphNode* nextGraphNode = currentGraphNode->next;
		delete currentGraphNode;
		currentGraphNode = nextGraphNode;
	}

	graph.head = nullptr;
}
