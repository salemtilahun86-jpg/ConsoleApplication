#include "../include/Menu.h"
#include "../include/SampleData.h"
#include <iostream>
#include <string>

namespace
{
const char* DEFAULT_FILE_NAME = "civil_records.txt";

std::string readText(const std::string& prompt)
{
	std::cout << prompt;
	std::string value;
	std::getline(std::cin, value);
	return value;
}

bool readInteger(const std::string& prompt, int& value)
{
	std::string input = readText(prompt);
	if (input.empty())
	{
		return false;
	}

	int sign = 1;
	int start = 0;
	if (input[0] == '-')
	{
		sign = -1;
		start = 1;
	}
	if (start == static_cast<int>(input.length()))
	{
		return false;
	}

	int result = 0;
	for (int i = start; i < static_cast<int>(input.length()); ++i)
	{
		if (input[i] < '0' || input[i] > '9')
		{
			return false;
		}
		result = result * 10 + (input[i] - '0');
	}

	value = sign * result;
	return true;
}

void displayHouseholdDetails(const Household& household)
{
	std::cout << "Household ID: " << household.householdID << "\n";
	std::cout << "City ID: " << household.cityID << "\n";
	std::cout << "Sub-city ID: " << household.subCityID << "\n";
	std::cout << "Woreda ID: " << household.woredaID << "\n";
	std::cout << "Address: " << household.address << "\n";
	std::cout << "Resident count: " << household.residentCount << "\n";
	displayResidents(household);

	std::cout << "Household-level civil events:\n";
	if (household.eventCount == 0)
	{
		std::cout << "  None.\n";
	}
	else
	{
		for (int i = 0; i < household.eventCount; ++i)
		{
			const CivilEvent& event = household.events[i];
			std::cout << "  " << event.eventID << " | " << event.eventType << " | " << event.eventDate
				<< " | " << event.notes << "\n";
		}
	}

	std::cout << "Household-level documents:\n";
	if (household.documentCount == 0)
	{
		std::cout << "  None.\n";
	}
	else
	{
		for (int i = 0; i < household.documentCount; ++i)
		{
			const Document& document = household.documents[i];
			std::cout << "  " << document.documentID << " | " << document.documentType
				<< " | " << document.issueDate << " | " << document.status << "\n";
		}
	}
}

void recordResidenceTransfer(Resident& resident, const std::string& sourceHouseholdID, const std::string& destinationHouseholdID, const std::string& startDate)
{
	ResidenceHistoryNode* currentResidence = resident.historyTail;
	if (currentResidence != nullptr && currentResidence->endDate == "Present")
	{
		currentResidence->endDate = startDate;
		currentResidence->notes = "Residence ended by transfer";
	}

	if (currentResidence == nullptr || currentResidence->householdID != sourceHouseholdID || currentResidence->endDate != startDate)
	{
		appendResidenceHistory(
			resident.historyHead,
			resident.historyTail,
			sourceHouseholdID,
			"Unknown",
			startDate,
			"Residence before transfer");
	}

	appendResidenceHistory(
		resident.historyHead,
		resident.historyTail,
		destinationHouseholdID,
		startDate,
		"Present",
		"Transferred to current household");
}

bool getResidentContext(Application& application, const std::string& residentID, ResidentNode*& residentNode, Household*& household)
{
	residentNode = findResidentByID(application.residentTable, residentID);
	if (residentNode == nullptr)
	{
		household = nullptr;
		return false;
	}

	household = findHouseholdContainingResident(application.householdTable, residentID);
	return household != nullptr;
}

void registerHousehold(Application& application)
{
	std::string householdID = readText("Household ID: ");
	if (findHouseholdByID(application.householdTable, householdID) != nullptr)
	{
		std::cout << "That household ID is already in use.\n";
		return;
	}

	std::string cityID = readText("City ID: ");
	std::string subCityID = readText("Sub-city ID: ");
	std::string woredaID = readText("Woreda ID: ");
	std::string address = readText("Address: ");
	if (findCity(application.administrativeSystem, cityID) == nullptr ||
		findSubCity(application.administrativeSystem, subCityID) == nullptr ||
		findWoreda(application.administrativeSystem, woredaID) == nullptr)
	{
		std::cout << "One or more administrative IDs do not exist.\n";
		return;
	}

	Household* household = new Household;
	initializeHousehold(*household, householdID, cityID, subCityID, woredaID, address);
	if (!insertHousehold(application.householdTable, household))
	{
		delete household;
		std::cout << "Household registration failed.\n";
		return;
	}

	std::cout << "Household registered successfully.\n";
}

void searchHousehold(Application& application)
{
	std::string householdID = readText("Enter Household ID: ");
	Household* household = findHouseholdByID(application.householdTable, householdID);
	if (household == nullptr)
	{
		std::cout << "Household not found.\n";
		return;
	}

	displayHouseholdDetails(*household);
}

void registerResident(Application& application)
{
	std::string householdID = readText("Household ID: ");
	Household* household = findHouseholdByID(application.householdTable, householdID);
	if (household == nullptr)
	{
		std::cout << "Household not found.\n";
		return;
	}

	std::string residentID = readText("Resident ID: ");
	if (findResidentByID(application.residentTable, residentID) != nullptr)
	{
		std::cout << "That resident ID is already in use.\n";
		return;
	}

	std::string fullName = readText("Full name: ");
	std::string dateOfBirth = readText("Date of birth: ");
	std::string gender = readText("Gender: ");
	if (findFamilyGraphNode(application.familyGraph, residentID) != nullptr)
	{
		std::cout << "A graph vertex already exists for that resident ID. Registration was not changed.\n";
		return;
	}

	if (!addResidentVertex(application.familyGraph, residentID))
	{
		std::cout << "Resident registration failed because the graph vertex could not be created.\n";
		return;
	}

	if (addResident(*household, application.residentTable, residentID, fullName, dateOfBirth, gender))
	{
		std::cout << "Resident registered successfully.\n";
	}
	else
	{
		removeResidentVertex(application.familyGraph, residentID);
		std::cout << "Resident registration failed.\n";
	}
}

void searchResident(Application& application)
{
	std::string residentID = readText("Enter Resident ID: ");
	ResidentNode* residentNode = nullptr;
	Household* household = nullptr;
	if (!getResidentContext(application, residentID, residentNode, household))
	{
		std::cout << "Resident not found.\n";
		return;
	}

	const Resident& resident = residentNode->data;
	std::cout << "Resident ID: " << resident.residentID << "\n";
	std::cout << "Full name: " << resident.fullName << "\n";
	std::cout << "Date of birth: " << resident.dateOfBirth << "\n";
	std::cout << "Gender: " << resident.gender << "\n";
	std::cout << "Current household: " << household->householdID << "\n";
}

void searchResidentByName(Application& application)
{
	std::string householdID = readText("Household ID: ");
	Household* household = findHouseholdByID(application.householdTable, householdID);
	if (household == nullptr)
	{
		std::cout << "Household not found.\n";
		return;
	}

	std::string fullName = readText("Full name: ");
	ResidentNode* residentNode = findResidentByName(*household, fullName);
	if (residentNode == nullptr)
	{
		std::cout << "Resident not found in that household.\n";
		return;
	}

	std::cout << "Linear search found " << residentNode->data.residentID
		<< " - " << residentNode->data.fullName << "\n";
}

void updateResident(Application& application)
{
	std::string residentID = readText("Resident ID: ");
	ResidentNode* residentNode = findResidentByID(application.residentTable, residentID);
	if (residentNode == nullptr)
	{
		std::cout << "Resident not found.\n";
		return;
	}

	int choice = 0;
	if (!readInteger("1. Update full name\n2. Update date of birth\n3. Update gender\nChoose field: ", choice))
	{
		std::cout << "Invalid choice.\n";
		return;
	}

	if (choice == 1)
	{
		residentNode->data.fullName = readText("New full name: ");
	}
	else if (choice == 2)
	{
		residentNode->data.dateOfBirth = readText("New date of birth: ");
	}
	else if (choice == 3)
	{
		residentNode->data.gender = readText("New gender: ");
	}
	else
	{
		std::cout << "Invalid choice.\n";
		return;
	}

	std::cout << "Resident updated. ResidentID and node identity were unchanged.\n";
}

void removeResidentFromApplication(Application& application)
{
	std::string residentID = readText("Resident ID: ");
	ResidentNode* residentNode = findResidentByID(application.residentTable, residentID);
	Household* household = findHouseholdContainingResident(application.householdTable, residentID);
	if (residentNode == nullptr || household == nullptr)
	{
		std::cout << "Resident not found.\n";
		return;
	}

	if (removeResident(*household, application.residentTable, residentID))
	{
		removeResidentVertex(application.familyGraph, residentID);
		std::cout << "Resident removed safely.\n";
	}
	else
	{
		std::cout << "Resident removal failed.\n";
	}
}

void transferResident(Application& application)
{
	std::string residentID = readText("Resident ID: ");
	std::string destinationID = readText("Destination Household ID: ");
	std::string startDate = readText("Transfer start date: ");

	ResidentNode* residentNode = findResidentByID(application.residentTable, residentID);
	Household* sourceHousehold = findHouseholdContainingResident(application.householdTable, residentID);
	Household* destinationHousehold = findHouseholdByID(application.householdTable, destinationID);
	if (residentNode == nullptr || sourceHousehold == nullptr || destinationHousehold == nullptr)
	{
		std::cout << "Resident or destination household was not found.\n";
		return;
	}
	if (sourceHousehold == destinationHousehold)
	{
		std::cout << "The resident is already in that household.\n";
		return;
	}
	if (findResident(*destinationHousehold, residentID) != nullptr)
	{
		std::cout << "The destination already contains that resident ID.\n";
		return;
	}

	ResidentNode* detachedNode = nullptr;
	if (!detachResidentNode(*sourceHousehold, residentID, detachedNode))
	{
		std::cout << "Resident could not be detached from the source household.\n";
		return;
	}

	if (!attachExistingResidentNode(*destinationHousehold, detachedNode))
	{
		attachExistingResidentNode(*sourceHousehold, detachedNode);
		std::cout << "Transfer failed; resident was returned to the source household.\n";
		return;
	}

	recordResidenceTransfer(detachedNode->data, sourceHousehold->householdID, destinationID, startDate);
	std::cout << "Resident transferred. The existing ResidentNode and hash pointer were preserved. Household-level civil events and documents remain with their original household.\n";
}

void sortResidentsInHousehold(Application& application)
{
	std::string householdID = readText("Household ID: ");
	Household* household = findHouseholdByID(application.householdTable, householdID);
	if (household == nullptr)
	{
		std::cout << "Household not found.\n";
		return;
	}

	std::cout << "Before sorting:\n";
	displayResidents(*household);
	mergeSortResidents(*household);
	std::cout << "After Merge Sort by full name:\n";
	displayResidents(*household);
}

void viewResidenceHistory(Application& application)
{
	std::string residentID = readText("Resident ID: ");
	ResidentNode* residentNode = findResidentByID(application.residentTable, residentID);
	if (residentNode == nullptr)
	{
		std::cout << "Resident not found.\n";
		return;
	}

	std::cout << "Residence history for " << residentNode->data.fullName << ":\n";
	displayResidenceHistory(residentNode->data.historyHead);
}

void registerCivilEvent(Application& application)
{
	std::string residentID = readText("Resident ID for the event context: ");
	ResidentNode* residentNode = nullptr;
	Household* household = nullptr;
	if (!getResidentContext(application, residentID, residentNode, household))
	{
		std::cout << "Resident not found.\n";
		return;
	}
	if (household->eventCount >= MAX_CIVIL_EVENTS)
	{
		std::cout << "The household civil-event array is full.\n";
		return;
	}

	CivilEvent& event = household->events[household->eventCount];
	event.eventID = "USER_EVENT_" + residentID;
	event.eventType = readText("Event type: ");
	event.eventDate = readText("Event date: ");
	event.notes = readText("Details: ");
	++household->eventCount;
	std::cout << "Civil event registered.\n";
}

void addDocumentToHousehold(Application& application)
{
	std::string residentID = readText("Resident ID for the document context: ");
	ResidentNode* residentNode = nullptr;
	Household* household = nullptr;
	if (!getResidentContext(application, residentID, residentNode, household))
	{
		std::cout << "Resident not found.\n";
		return;
	}
	if (household->documentCount >= MAX_DOCUMENTS)
	{
		std::cout << "The household document array is full.\n";
		return;
	}

	Document& document = household->documents[household->documentCount];
	document.documentID = readText("Document ID: ");
	document.documentType = readText("Document type: ");
	document.issueDate = readText("Issue date: ");
	document.status = readText("Status: ");
	++household->documentCount;
	std::cout << "Document added.\n";
}

void viewFamilyRelationships(Application& application)
{
	std::string residentID = readText("Resident ID: ");
	displayRelationships(application.familyGraph, residentID);
}

void traverseFamilyGraph(Application& application)
{
	std::string residentID = readText("Starting Resident ID: ");
	displayDFS(application.familyGraph, residentID);
}

void saveApplication(Application& application)
{
	std::string fileName = readText("Filename (press Enter for civil_records.txt): ");
	if (fileName.empty())
	{
		fileName = DEFAULT_FILE_NAME;
	}

	if (saveToTextFile(fileName.c_str(), application.householdTable, application.familyGraph))
	{
		std::cout << "Data saved to " << fileName << ".\n";
	}
	else
	{
		std::cout << "Data could not be saved.\n";
	}
}

void loadApplication(Application& application)
{
	std::string fileName = readText("Filename (press Enter for civil_records.txt): ");
	if (fileName.empty())
	{
		fileName = DEFAULT_FILE_NAME;
	}

	if (loadFromTextFile(fileName.c_str(), application.householdTable, application.residentTable, application.familyGraph))
	{
		application.sampleDataLoaded = false;
		std::cout << "Data loaded from " << fileName << ".\n";
	}
	else
	{
		application.sampleDataLoaded = false;
		std::cout << "Data could not be loaded. Current records were cleared before reconstruction.\n";
	}
}

void displayMenu()
{
	std::cout << "\n=============================================\n";
	std::cout << " Civil Registration and Residency Management\n";
	std::cout << "=============================================\n";
	std::cout << "1. Load Sample Data\n";
	std::cout << "2. Register Household\n";
	std::cout << "3. Search Household\n";
	std::cout << "4. Display All Households\n";
	std::cout << "5. Register Resident\n";
	std::cout << "6. Search Resident\n";
	std::cout << "7. Search Resident by Name\n";
	std::cout << "8. Update Resident\n";
	std::cout << "9. Remove Resident\n";
	std::cout << "10. Transfer Resident\n";
	std::cout << "11. Sort Residents\n";
	std::cout << "12. View Residence History\n";
	std::cout << "13. Register Civil Event\n";
	std::cout << "14. Add Document\n";
	std::cout << "15. View Family Relationships\n";
	std::cout << "16. DFS Family Relationship Traversal\n";
	std::cout << "17. Save Data\n";
	std::cout << "18. Load Data\n";
	std::cout << "19. Run Integration Test\n";
	std::cout << "0. Exit\n";
}
}

void initializeApplication(Application& application)
{
	initializeAdministrativeSystem(application.administrativeSystem);
	initializeHouseholdHashTable(application.householdTable);
	initializeResidentHashTable(application.residentTable);
	initializeFamilyGraph(application.familyGraph);
	application.sampleDataLoaded = false;
}

void destroyApplication(Application& application)
{
	clearApplicationData(application.householdTable, application.residentTable, application.familyGraph);
	initializeAdministrativeSystem(application.administrativeSystem);
	application.sampleDataLoaded = false;
}

void runApplication()
{
	Application application;
	initializeApplication(application);
	std::cout << "All records are fictional academic prototype data.\n";

	bool running = true;
	while (running && !std::cin.eof())
	{
		displayMenu();
		int choice = 0;
		if (!readInteger("\nEnter your choice: ", choice))
		{
			if (std::cin.eof())
			{
				break;
			}
			std::cout << "Please enter a valid number.\n";
			continue;
		}

		switch (choice)
		{
		case 1:
			if (loadSampleData(application))
			{
				std::cout << "Fictional Addis Ababa sample data loaded.\n";
			}
			else
			{
				std::cout << "Sample data is already loaded or records already exist.\n";
			}
			break;
		case 2:
			registerHousehold(application);
			break;
		case 3:
			searchHousehold(application);
			break;
		case 4:
			displayOrderedHouseholdReport(application.householdTable);
			break;
		case 5:
			registerResident(application);
			break;
		case 6:
			searchResident(application);
			break;
		case 7:
			searchResidentByName(application);
			break;
		case 8:
			updateResident(application);
			break;
		case 9:
			removeResidentFromApplication(application);
			break;
		case 10:
			transferResident(application);
			break;
		case 11:
			sortResidentsInHousehold(application);
			break;
		case 12:
			viewResidenceHistory(application);
			break;
		case 13:
			registerCivilEvent(application);
			break;
		case 14:
			addDocumentToHousehold(application);
			break;
		case 15:
			viewFamilyRelationships(application);
			break;
		case 16:
			traverseFamilyGraph(application);
			break;
		case 17:
			saveApplication(application);
			break;
		case 18:
			loadApplication(application);
			break;
		case 19:
			if (!runIntegrationTest())
			{
				std::cout << "Integration test failed.\n";
			}
			break;
		case 0:
			running = false;
			break;
		default:
			std::cout << "Unknown menu choice.\n";
			break;
		}
	}

	destroyApplication(application);
	std::cout << "Application closed.\n";
}
