#include "../include/SampleData.h"
#include "../include/Menu.h"
#include <cstdio>
#include <fstream>
#include <iostream>
#include <string>

namespace
{
Household* createAndInsertHousehold(Application& application, const std::string& householdID, const std::string& cityID, const std::string& subCityID, const std::string& woredaID, const std::string& address)
{
	Household* household = new Household;
	initializeHousehold(*household, householdID, cityID, subCityID, woredaID, address);
	if (!insertHousehold(application.householdTable, household))
	{
		delete household;
		return nullptr;
	}

	return household;
}

bool addEvent(Household& household, const std::string& eventID, const std::string& eventType, const std::string& eventDate, const std::string& notes)
{
	if (household.eventCount >= MAX_CIVIL_EVENTS)
	{
		return false;
	}

	CivilEvent& event = household.events[household.eventCount];
	event.eventID = eventID;
	event.eventType = eventType;
	event.eventDate = eventDate;
	event.notes = notes;
	++household.eventCount;
	return true;
}

bool addDocument(Household& household, const std::string& documentID, const std::string& documentType, const std::string& issueDate, const std::string& status)
{
	if (household.documentCount >= MAX_DOCUMENTS)
	{
		return false;
	}

	Document& document = household.documents[household.documentCount];
	document.documentID = documentID;
	document.documentType = documentType;
	document.issueDate = issueDate;
	document.status = status;
	++household.documentCount;
	return true;
}

bool integrationFailure(Application& application, const char* message)
{
	std::cerr << "Integration test failed: " << message << "\n";
	destroyApplication(application);
	return false;
}

bool containsLineStartingWith(const char* fileName, const std::string& prefix)
{
	std::ifstream inputFile(fileName);
	if (!inputFile.is_open())
	{
		return false;
	}

	std::string line;
	while (std::getline(inputFile, line))
	{
		if (line.find(prefix) == 0)
		{
			return true;
		}
	}

	return false;
}

bool visitedContains(const std::string visitedIDs[], int visitedCount, const std::string& residentID)
{
	for (int i = 0; i < visitedCount; ++i)
	{
		if (visitedIDs[i] == residentID)
		{
			return true;
		}
	}

	return false;
}

bool verifyBidirectionalRelationshipRecovery()
{
	FamilyGraph graph;
	initializeFamilyGraph(graph);
	if (!addResidentVertex(graph, "TEST-A") || !addResidentVertex(graph, "TEST-B") ||
		!addRelationship(graph, "TEST-A", "TEST-B", "Spouse", false) ||
		!addRelationship(graph, "TEST-A", "TEST-B", "Spouse", true) ||
		!relationshipExists(graph, "TEST-A", "TEST-B", "Spouse") ||
		!relationshipExists(graph, "TEST-B", "TEST-A", "Spouse") ||
		!removeRelationship(graph, "TEST-A", "TEST-B", "Spouse", true) ||
		!addRelationship(graph, "TEST-A", "TEST-B", "Spouse", false) ||
		!removeRelationship(graph, "TEST-B", "TEST-A", "Spouse", true) ||
		relationshipExists(graph, "TEST-A", "TEST-B", "Spouse") ||
		relationshipExists(graph, "TEST-B", "TEST-A", "Spouse"))
	{
		destroyFamilyGraph(graph);
		return false;
	}

	destroyFamilyGraph(graph);
	return true;
}
}

bool loadSampleData(Application& application)
{
	if (application.sampleDataLoaded || countHouseholds(application.householdTable) != 0)
	{
		return false;
	}

	initializeAdministrativeSystem(application.administrativeSystem);
	if (!addCity(application.administrativeSystem, "C001", "Addis Ababa") ||
		!addSubCity(application.administrativeSystem, "SC001", "Bole", "C001") ||
		!addSubCity(application.administrativeSystem, "SC002", "Yeka", "C001") ||
		!addSubCity(application.administrativeSystem, "SC003", "Kirkos", "C001") ||
		!addSubCity(application.administrativeSystem, "SC004", "Lemi Kura", "C001") ||
		!addWoreda(application.administrativeSystem, "W001", "Woreda 03", "SC001") ||
		!addWoreda(application.administrativeSystem, "W002", "Woreda 08", "SC001") ||
		!addWoreda(application.administrativeSystem, "W003", "Woreda 05", "SC002") ||
		!addWoreda(application.administrativeSystem, "W004", "Woreda 02", "SC003") ||
		!addWoreda(application.administrativeSystem, "W005", "Woreda 04", "SC004"))
	{
		return false;
	}

	Household* householdOne = createAndInsertHousehold(application, "H001", "C001", "SC001", "W001", "Kebele 03, House 124");
	Household* householdTwo = createAndInsertHousehold(application, "H002", "C001", "SC001", "W002", "Kebele 07, House 218");
	Household* householdThree = createAndInsertHousehold(application, "H003", "C001", "SC002", "W003", "Kebele 05, House 091");
	Household* householdFour = createAndInsertHousehold(application, "H004", "C001", "SC003", "W004", "Kebele 02, House 157");
	Household* householdFive = createAndInsertHousehold(application, "H005", "C001", "SC004", "W005", "Kebele 04, House 306");
	if (householdOne == nullptr || householdTwo == nullptr || householdThree == nullptr || householdFour == nullptr || householdFive == nullptr)
	{
		clearApplicationData(application.householdTable, application.residentTable, application.familyGraph);
		return false;
	}

	if (!addResident(*householdOne, application.residentTable, "R001", "Abebe Bekele", "1998-04-12", "Male") ||
		!addResident(*householdOne, application.residentTable, "R002", "Hana Abebe", "2000-08-21", "Female") ||
		!addResident(*householdOne, application.residentTable, "R003", "Liya Abebe", "2022-02-15", "Female") ||
		!addResident(*householdTwo, application.residentTable, "R004", "Dawit Tesfaye", "1995-11-03", "Male") ||
		!addResident(*householdTwo, application.residentTable, "R005", "Mekdes Dawit", "1997-06-18", "Female") ||
		!addResident(*householdThree, application.residentTable, "R006", "Samuel Girma", "1992-01-27", "Male") ||
		!addResident(*householdThree, application.residentTable, "R007", "Selamawit Samuel", "1994-09-10", "Female") ||
		!addResident(*householdFour, application.residentTable, "R008", "Bethlehem Tadesse", "2001-03-05", "Female") ||
		!addResident(*householdFive, application.residentTable, "R009", "Yonas Alemu", "1989-12-14", "Male") ||
		!addResident(*householdFive, application.residentTable, "R010", "Rahel Yonas", "1991-07-22", "Female"))
	{
		clearApplicationData(application.householdTable, application.residentTable, application.familyGraph);
		return false;
	}

	ResidentNode* residentOne = findResident(*householdOne, "R001");
	ResidentNode* residentFour = findResident(*householdTwo, "R004");
	appendResidenceHistory(residentOne->data.historyHead, residentOne->data.historyTail, "H003", "2020-01-15", "2024-06-30", "Previous residence");
	appendResidenceHistory(residentOne->data.historyHead, residentOne->data.historyTail, "H001", "2024-07-01", "Present", "Transferred to current household");
	appendResidenceHistory(residentFour->data.historyHead, residentFour->data.historyTail, "H002", "2019-03-01", "Present", "Current residence");

	if (!addEvent(*householdOne, "R001-E001", "Birth", "1998-04-12", "Birth registered") ||
		!addEvent(*householdOne, "R001-E002", "Marriage", "2023-10-21", "Marriage registered") ||
		!addEvent(*householdOne, "R002-E001", "Birth", "2000-08-21", "Birth registered") ||
		!addEvent(*householdOne, "R002-E002", "Marriage", "2023-10-21", "Marriage registered") ||
		!addEvent(*householdOne, "R003-E001", "Birth", "2022-02-15", "Birth registered") ||
		!addDocument(*householdOne, "DOC001", "Birth Certificate", "1998-04-20", "Verified") ||
		!addDocument(*householdOne, "DOC002", "National ID Record", "2024-01-10", "Verified") ||
		!addDocument(*householdOne, "DOC003", "Birth Certificate", "2000-08-30", "Verified") ||
		!addDocument(*householdOne, "DOC004", "Birth Certificate", "2022-02-20", "Verified"))
	{
		clearApplicationData(application.householdTable, application.residentTable, application.familyGraph);
		return false;
	}

	const char* residentIDs[10] = { "R001", "R002", "R003", "R004", "R005", "R006", "R007", "R008", "R009", "R010" };
	for (int i = 0; i < 10; ++i)
	{
		if (!addResidentVertex(application.familyGraph, residentIDs[i]))
		{
			clearApplicationData(application.householdTable, application.residentTable, application.familyGraph);
			return false;
		}
	}

	if (!addRelationship(application.familyGraph, "R001", "R002", "Spouse", true) ||
		!addRelationship(application.familyGraph, "R001", "R003", "Parent", false) ||
		!addRelationship(application.familyGraph, "R002", "R003", "Parent", false) ||
		!addRelationship(application.familyGraph, "R004", "R005", "Spouse", true) ||
		!addRelationship(application.familyGraph, "R006", "R007", "Spouse", true) ||
		!addRelationship(application.familyGraph, "R009", "R010", "Spouse", true))
	{
		clearApplicationData(application.householdTable, application.residentTable, application.familyGraph);
		return false;
	}

	application.sampleDataLoaded = true;
	return true;
}

bool runIntegrationTest()
{
	Application application;
	initializeApplication(application);
	if (!loadSampleData(application))
	{
		return integrationFailure(application, "sample data could not be loaded");
	}

	if (findCity(application.administrativeSystem, "C001") == nullptr ||
		findSubCity(application.administrativeSystem, "SC001") == nullptr ||
		findSubCity(application.administrativeSystem, "SC002") == nullptr ||
		findSubCity(application.administrativeSystem, "SC003") == nullptr ||
		findSubCity(application.administrativeSystem, "SC004") == nullptr ||
		findWoreda(application.administrativeSystem, "W005") == nullptr)
	{
		return integrationFailure(application, "administrative search failed");
	}

	Household* householdOne = findHouseholdByID(application.householdTable, "H001");
	Household* householdThree = findHouseholdByID(application.householdTable, "H003");
	if (householdOne == nullptr || householdThree == nullptr || findHouseholdByID(application.householdTable, "H999") != nullptr)
	{
		return integrationFailure(application, "household search failed");
	}

	ResidentNode* residentOne = findResidentByID(application.residentTable, "R001");
	if (residentOne == nullptr || findResidentByID(application.residentTable, "R999") != nullptr ||
		findHouseholdContainingResident(application.householdTable, "R001") != householdOne ||
		findResidentByName(*householdOne, "Abebe Bekele") != residentOne)
	{
		return integrationFailure(application, "resident search failed");
	}

	int householdCount = 0;
	Household** householdPointers = createTemporaryHouseholdPointerArray(application.householdTable, householdCount);
	if (householdPointers == nullptr || householdCount != 5)
	{
		deleteTemporaryHouseholdPointerArray(householdPointers);
		return integrationFailure(application, "ordered household array creation failed");
	}
	sortHouseholdPointers(householdPointers, householdCount);
	if (householdPointers[0] != findHouseholdByID(application.householdTable, "H001") ||
		householdPointers[4] != findHouseholdByID(application.householdTable, "H005") ||
		binarySearchHouseholds(householdPointers, householdCount, "H003") != householdThree ||
		binarySearchHouseholds(householdPointers, householdCount, "H999") != nullptr)
	{
		deleteTemporaryHouseholdPointerArray(householdPointers);
		return integrationFailure(application, "ordered household report or Binary Search failed");
	}
	deleteTemporaryHouseholdPointerArray(householdPointers);

	Household* householdFive = findHouseholdByID(application.householdTable, "H005");
	ResidentNode* residentNine = findResident(*householdFive, "R009");
	ResidentNode* residentTen = findResident(*householdFive, "R010");
	mergeSortResidents(*householdFive);
	if (householdFive->residentHead != residentTen || householdFive->residentTail != residentNine)
	{
		return integrationFailure(application, "resident Merge Sort order failed");
	}

	std::string visitedResidents[10];
	int visitedCount = dfs(application.familyGraph, "R001", visitedResidents, 10);
	if (visitedCount != 3 || !visitedContains(visitedResidents, visitedCount, "R001") ||
		!visitedContains(visitedResidents, visitedCount, "R002") ||
		!visitedContains(visitedResidents, visitedCount, "R003"))
	{
		return integrationFailure(application, "family graph DFS failed");
	}
	if (!verifyBidirectionalRelationshipRecovery())
	{
		return integrationFailure(application, "bidirectional relationship recovery failed");
	}

	const char* fileName = "batch5_integration_data.txt";
	if (!saveToTextFile(fileName, application.householdTable, application.familyGraph) ||
		!containsLineStartingWith(fileName, "HOUSEHOLD|H001") ||
		!containsLineStartingWith(fileName, "RESIDENT|R001") ||
		!containsLineStartingWith(fileName, "HISTORY|") ||
		!containsLineStartingWith(fileName, "EVENT|") ||
		!containsLineStartingWith(fileName, "DOCUMENT|") ||
		!containsLineStartingWith(fileName, "RELATION|"))
	{
		std::remove(fileName);
		return integrationFailure(application, "text save or file-content validation failed");
	}

	destroyApplication(application);
	if (!loadFromTextFile(fileName, application.householdTable, application.residentTable, application.familyGraph))
	{
		std::remove(fileName);
		return integrationFailure(application, "text load failed");
	}

	Household* loadedHouseholdOne = findHouseholdByID(application.householdTable, "H001");
	ResidentNode* loadedResidentOne = findResidentByID(application.residentTable, "R001");
	if (loadedHouseholdOne == nullptr || loadedHouseholdOne->residentCount != 3 || loadedResidentOne == nullptr ||
		loadedResidentOne != findResident(*loadedHouseholdOne, "R001") ||
		loadedResidentOne->data.historyHead == nullptr ||
		loadedHouseholdOne->eventCount != 5 || loadedHouseholdOne->documentCount != 4 ||
		!relationshipExists(application.familyGraph, "R001", "R002", "Spouse") ||
		!relationshipExists(application.familyGraph, "R001", "R003", "Parent"))
	{
		std::remove(fileName);
		return integrationFailure(application, "loaded records were incomplete");
	}

	std::string loadedVisitedResidents[10];
	int loadedVisitedCount = dfs(application.familyGraph, "R001", loadedVisitedResidents, 10);
	if (loadedVisitedCount != 3)
	{
		std::remove(fileName);
		return integrationFailure(application, "DFS after loading failed");
	}

	destroyApplication(application);
	std::remove(fileName);
	std::cout << "Final integration test passed.\n";
	return true;
}
