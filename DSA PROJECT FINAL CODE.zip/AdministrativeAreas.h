#pragma once

#include <string>
#include "Constants.h"

struct City
{
	std::string cityID;
	std::string name;
};

struct SubCity
{
	std::string subCityID;
	std::string name;
	std::string cityID;
};

struct Woreda
{
	std::string woredaID;
	std::string name;
	std::string subCityID;
};

struct AdministrativeSystem
{
	City cities[MAX_CITIES];
	SubCity subCities[MAX_SUBCITIES];
	Woreda woredas[MAX_WOREDAS];

	int cityCount;
	int subCityCount;
	int woredaCount;
};

void initializeAdministrativeSystem(AdministrativeSystem& system);

bool addCity(AdministrativeSystem& system, const std::string& cityID, const std::string& name);
bool addSubCity(AdministrativeSystem& system, const std::string& subCityID, const std::string& name, const std::string& cityID);
bool addWoreda(AdministrativeSystem& system, const std::string& woredaID, const std::string& name, const std::string& subCityID);

City* findCity(AdministrativeSystem& system, const std::string& cityID);
SubCity* findSubCity(AdministrativeSystem& system, const std::string& subCityID);
Woreda* findWoreda(AdministrativeSystem& system, const std::string& woredaID);

void displayAdministrativeSystem(const AdministrativeSystem& system);
