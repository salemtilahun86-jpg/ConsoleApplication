#pragma once

#include <string>
#include "Constants.h"
#include "CivilEvent.h"
#include "Document.h"
#include "Resident.h"
#include "ResidentHashTable.h"

struct Household
{
	std::string householdID;
	std::string cityID;
	std::string subCityID;
	std::string woredaID;
	std::string address;

	ResidentNode* residentHead;
	ResidentNode* residentTail;
	int residentCount;

	CivilEvent events[MAX_CIVIL_EVENTS];
	int eventCount;

	Document documents[MAX_DOCUMENTS];
	int documentCount;
};

void initializeHousehold(Household& household, const std::string& householdID, const std::string& cityID, const std::string& subCityID, const std::string& woredaID, const std::string& address);

bool addResident(Household& household, ResidentHashTable& residentTable, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender);
bool addResidentToBeginning(Household& household, ResidentHashTable& residentTable, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender);
bool addResidentToEnd(Household& household, ResidentHashTable& residentTable, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender);
ResidentNode* findResident(Household& household, const std::string& residentID);
ResidentNode* findResidentByName(Household& household, const std::string& fullName);
bool removeResident(Household& household, ResidentHashTable& residentTable, const std::string& residentID);
bool detachResidentNode(Household& household, const std::string& residentID, ResidentNode*& detachedNode);
bool attachExistingResidentNode(Household& household, ResidentNode* residentNode);
void displayResidents(const Household& household);
void displayResidentsBackward(const Household& household);
void clearHouseholdResidents(Household& household, ResidentHashTable& residentTable);
void mergeSortResidents(Household& household);
