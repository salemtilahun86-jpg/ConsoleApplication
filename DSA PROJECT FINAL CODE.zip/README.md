# Civil Registration and Residency Record Management System

## 1. Project Overview

The **Civil Registration and Residency Record Management System** is an academic C++ prototype developed for a Data Structures and Algorithms project.

The system demonstrates how civil registration and residency-related records can be organized and processed using appropriate data structures and algorithms. The prototype focuses on administrative areas, households, residents, residence history, civil events, documents, family relationships, searching, sorting, resident transfers, and text-based persistence.

The administrative demonstration is primarily based on **fictional Addis Ababa data**, with a second fictional Ethiopian city included to demonstrate support for multiple administrative areas.

> **Note:** All names, identifiers, household numbers, addresses, events, documents, and relationships used by the program are fictional prototype data. They do not represent real personal records or actual government records.

---

## 2. Main Features

The system provides the following functionality:

* Administrative area organization using City, Sub-city, and Woreda records
* Household registration and management
* Resident registration and management
* Resident search by ID and name
* Household search by ID
* Global resident lookup using Resident ID
* Dynamic resident membership using doubly linked lists
* Resident sorting using Merge Sort
* Household ordered reporting using a temporary pointer array
* Residence history management
* Resident transfer between households
* Civil event management
* Document management
* Family relationship management
* Family relationship traversal using DFS
* Text-file saving and loading
* Integrated testing of major system operations
* Interactive console-based application

---

## 3. Data Structures

The system uses different data structures according to the requirements of each type of record.

### Administrative Areas

Fixed-size arrays store:

* `City`
* `SubCity`
* `Woreda`

The prototype follows the administrative hierarchy:

```text
City
  └── Sub-city
       └── Woreda
            └── Household
                 └── Residents
```

### Households

`HouseholdHashTable` stores households using:

```text
Household ID → Household*
```

The hash table uses **separate chaining** for collision handling.

### Residents

Each household maintains its residents using a **doubly linked list** of `ResidentNode` objects.

A separate `ResidentHashTable` provides system-wide lookup using:

```text
Resident ID → ResidentNode*
```

The hash table stores pointers to the existing resident nodes rather than duplicate resident records.

### Residence History

Each resident maintains residence history using a **singly linked list**, allowing multiple previous residence records to be retained.

### Civil Events and Documents

Civil events and documents are stored using fixed-size arrays associated with households.

### Family Relationships

Family relationships are represented using a manually implemented **adjacency-list graph**.

Resident IDs identify graph vertices, while relationships are represented by edges.

---

## 4. Algorithms

The main algorithms implemented in the system are:

* **Hashing with Separate Chaining** — used for efficient household and resident ID lookup.
* **Linear Search** — used for sequential collections such as resident lists and administrative records.
* **Merge Sort** — used to sort residents by full name directly on the doubly linked list.
* **Selection Sort** — used to order a temporary array of household pointers for reporting.
* **Binary Search** — used on the sorted temporary household-pointer array.
* **Depth-First Search (DFS)** — used to traverse family relationships in the adjacency-list graph.

### Typical Complexity

| Operation                      |   Complexity |
| ------------------------------ | -----------: |
| Household/Resident hash lookup | O(1) average |
| Linear search                  |         O(n) |
| Binary Search                  |     O(log n) |
| Resident Merge Sort            |   O(n log n) |
| Household Selection Sort       |        O(h²) |
| Graph DFS                      |     O(V + E) |

Merge Sort relinks the existing resident nodes rather than creating replacement resident nodes. This preserves the node references used by the resident hash table.

---

## 5. Memory Ownership

The system uses explicit ownership rules to manage dynamically allocated objects.

* The application manager owns `Household` objects.
* Each `Household` owns its `ResidentNode` objects.
* Each `Resident` owns its residence-history nodes.
* `HouseholdHashTable` owns its hash-chain nodes.
* `ResidentHashTable` owns its hash-chain nodes.
* `FamilyGraph` owns its graph and adjacency-list nodes.
* The family graph stores resident IDs and does not own resident objects.

Temporary household-pointer arrays are created only when needed for ordered reports and are released after use.

The application also performs cleanup of dynamically allocated records and associated references when records are removed or when the application exits.

---

## 6. Data Persistence

The system provides text-based persistence using C++ file streams.

Records are saved using `std::ofstream` and loaded using `std::ifstream`.

The persistence format uses identifiable text markers such as:

```text
HOUSEHOLD
RESIDENT
HISTORY
EVENT
DOCUMENT
VERTEX
RELATION
END_RESIDENT
END_HOUSEHOLD
```

The saved data does not contain memory addresses or raw pointer values.

When data is loaded, the system reconstructs the required household, resident, history, event, document, and family-relationship structures.

The default save file is:

```text
civil_records.txt
```

A different filename can also be provided through the application.

---

## 7. Project Structure

The main project modules are organized as follows:

```text
ConsoleApplication1/
├── include/
│   ├── Constants.h
│   ├── AdministrativeAreas.h
│   ├── CivilEvent.h
│   ├── Document.h
│   ├── ResidenceHistory.h
│   ├── Resident.h
│   ├── Household.h
│   ├── HouseholdHashTable.h
│   ├── ResidentHashTable.h
│   ├── FamilyGraph.h
│   ├── Persistence.h
│   ├── SampleData.h
│   └── Menu.h
│
├── src/
│   ├── AdministrativeAreas.cpp
│   ├── ResidenceHistory.cpp
│   ├── Resident.cpp
│   ├── Household.cpp
│   ├── HouseholdHashTable.cpp
│   ├── ResidentHashTable.cpp
│   ├── FamilyGraph.cpp
│   ├── Persistence.cpp
│   ├── SampleData.cpp
│   └── Menu.cpp
│
├── data/
│   └── sample_data.txt
│
├── ConsoleApplication1.cpp
└── ConsoleApplication1.slnx
```

`ConsoleApplication1.cpp` contains the program entry point and starts the interactive application through `runApplication()`.

---

## 8. Building and Running

### Requirements

* Microsoft Visual Studio with C++ development support
* A Windows environment capable of building the Visual Studio project

### Steps

1. Open:

```text
ConsoleApplication1.slnx
```

in Visual Studio.

2. Build the solution/project.

3. Run the application using **Start Without Debugging** or **Start Debugging**.

4. From the main menu, choose **Load Sample Data** to load the fictional Addis Ababa demonstration records.

5. Use the menu to perform searches, registration, updating, sorting, transfers, relationship traversal, saving, and loading.

6. Use the integration-test option to execute the system's integrated validation tests.

7. Choose the exit option to close the application and perform cleanup.

---

## 9. Sample Data

The demonstration data is primarily centered on Addis Ababa.

Example administrative records include:

```text
C001 - Addis Ababa
C002 - Adama

SC001 - Bole
SC002 - Yeka
SC003 - Kirkos
SC004 - Lemi Kura
```

Example households include:

```text
H001 - Bole - Woreda 03
H002 - Bole - Woreda 08
H003 - Yeka - Woreda 05
H004 - Kirkos - Woreda 02
H005 - Bole - Woreda 03
```

All associated resident, event, document, relationship, and residence-history records are fictional prototype data.

---

## 10. Testing

The project includes tests covering the major implemented structures and operations, including:

* Administrative and household searching
* Resident ID and name searching
* Doubly linked-list insertion and removal
* Resident Merge Sort
* Resident-node reference preservation during sorting
* Household ordering and Binary Search
* Hash-table collision handling
* Family graph and DFS traversal
* Resident transfer
* Residence-history preservation
* Civil events and documents
* Save/load reconstruction
* Resident deletion and graph cleanup
* Integrated end-to-end workflow

The final Debug/x64 build and integration testing were used to verify the completed implementation.

---

## 11. Project Scope

This project is an **academic prototype** designed to demonstrate the application of data structures and algorithms to a realistic civil registration and residency-management problem.

It is not intended to reproduce the complete internal architecture, infrastructure, security model, or operational procedures of an actual government information system.

The prototype uses a console interface and text-file persistence rather than a production database, web interface, authentication infrastructure, or external government services.

---

## 12. Demonstration Flow

For a project demonstration, the following sequence provides a clear overview of the main functionality:

1. Load the fictional Addis Ababa sample data.
2. Display the administrative and household records.
3. Search for a household such as `H001`.
4. Search for a resident such as `R001`.
5. Search for a resident by name.
6. Sort the residents of a household by full name.
7. Display the resident's residence history.
8. Display family relationships and perform DFS traversal.
9. Register or update a resident.
10. Transfer a resident to another household.
11. Save the records to a text file.
12. Load the records again and verify reconstruction.
13. Run the integration test.

This sequence demonstrates the major data structures, algorithms, and record-management operations implemented in the project.
