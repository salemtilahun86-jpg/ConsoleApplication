#pragma once

#include <string>
#include "Constants.h"
#include "Household.h"

struct HouseholdHashNode
{
	std::string key;
	Household* household;
	HouseholdHashNode* next;
};

struct HouseholdHashTable
{
	HouseholdHashNode* buckets[HOUSEHOLD_HASH_SIZE];
};

void initializeHouseholdHashTable(HouseholdHashTable& table);
int hashHouseholdID(const std::string& key);
bool insertHousehold(HouseholdHashTable& table, Household* household);
Household* findHouseholdByID(const HouseholdHashTable& table, const std::string& householdID);
Household* findHouseholdContainingResident(const HouseholdHashTable& table, const std::string& residentID);
bool removeHouseholdFromHashTable(HouseholdHashTable& table, const std::string& householdID);
int countHouseholds(const HouseholdHashTable& table);
int copyHouseholdPointers(const HouseholdHashTable& table, Household* householdPointers[], int capacity);
Household** createTemporaryHouseholdPointerArray(const HouseholdHashTable& table, int& householdCount);
void deleteTemporaryHouseholdPointerArray(Household** householdPointers);
void sortHouseholdPointers(Household* householdPointers[], int householdCount);
Household* binarySearchHouseholds(Household* householdPointers[], int householdCount, const std::string& householdID);
void displayHouseholdsInHashOrder(const HouseholdHashTable& table);
void displayOrderedHouseholdReport(const HouseholdHashTable& table);
void destroyHouseholdHashTable(HouseholdHashTable& table);
