#include "ResidenceHistory.h"
#include <iostream>

void appendResidenceHistory(
	ResidenceHistoryNode*& head,
	ResidenceHistoryNode*& tail,
	const std::string& householdID,
	const std::string& startDate,
	const std::string& endDate,
	const std::string& notes)
{
	ResidenceHistoryNode* newNode = new ResidenceHistoryNode;
	newNode->householdID = householdID;
	newNode->startDate = startDate;
	newNode->endDate = endDate;
	newNode->notes = notes;
	newNode->next = nullptr;

	if (head == nullptr)
	{
		head = newNode;
		tail = newNode;
	}
	else
	{
		tail->next = newNode;
		tail = newNode;
	}
}

void displayResidenceHistory(const ResidenceHistoryNode* head)
{
	const ResidenceHistoryNode* current = head;
	while (current != nullptr)
	{
		std::cout << "  Household: " << current->householdID
			<< ", From: " << current->startDate
			<< ", To: " << current->endDate
			<< ", Notes: " << current->notes << "\n";
		current = current->next;
	}
}

void clearResidenceHistory(ResidenceHistoryNode*& head, ResidenceHistoryNode*& tail)
{
	ResidenceHistoryNode* current = head;
	while (current != nullptr)
	{
		ResidenceHistoryNode* nextNode = current->next;
		delete current;
		current = nextNode;
	}

	head = nullptr;
	tail = nullptr;
}
