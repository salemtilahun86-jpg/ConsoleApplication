#include "Resident.h"

void initializeResident(Resident& resident, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender)
{
	resident.residentID = residentID;
	resident.fullName = fullName;
	resident.dateOfBirth = dateOfBirth;
	resident.gender = gender;
	resident.historyHead = nullptr;
	resident.historyTail = nullptr;
}

ResidentNode* createResidentNode(const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender)
{
	ResidentNode* newNode = new ResidentNode;
	initializeResident(newNode->data, residentID, fullName, dateOfBirth, gender);
	newNode->prev = nullptr;
	newNode->next = nullptr;
	return newNode;
}

void clearResidentHistory(Resident& resident)
{
	clearResidenceHistory(resident.historyHead, resident.historyTail);
}
