#pragma once

#include <string>

struct CivilEvent
{
	std::string eventID;
	std::string eventType;
	std::string eventDate;
	std::string notes;
};
