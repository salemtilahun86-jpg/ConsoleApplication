#include "HouseholdHashTable.h"
#include <iostream>

void initializeHouseholdHashTable(HouseholdHashTable& table)
{
	for (int i = 0; i < HOUSEHOLD_HASH_SIZE; ++i)
	{
		table.buckets[i] = nullptr;
	}
}

int hashHouseholdID(const std::string& key)
{
	int characterSum = 0;
	for (int i = 0; i < static_cast<int>(key.length()); ++i)
	{
		characterSum += static_cast<unsigned char>(key[i]);
	}

	return characterSum % HOUSEHOLD_HASH_SIZE;
}

bool insertHousehold(HouseholdHashTable& table, Household* household)
{
	if (household == nullptr || findHouseholdByID(table, household->householdID) != nullptr)
	{
		return false;
	}

	int bucketIndex = hashHouseholdID(household->householdID);
	HouseholdHashNode* newNode = new HouseholdHashNode;
	newNode->key = household->householdID;
	newNode->household = household;
	newNode->next = table.buckets[bucketIndex];
	table.buckets[bucketIndex] = newNode;
	return true;
}

Household* findHouseholdByID(const HouseholdHashTable& table, const std::string& householdID)
{
	int bucketIndex = hashHouseholdID(householdID);
	HouseholdHashNode* current = table.buckets[bucketIndex];
	while (current != nullptr)
	{
		if (current->key == householdID)
		{
			return current->household;
		}
		current = current->next;
	}

	return nullptr;
}

Household* findHouseholdContainingResident(const HouseholdHashTable& table, const std::string& residentID)
{
	for (int i = 0; i < HOUSEHOLD_HASH_SIZE; ++i)
	{
		HouseholdHashNode* householdNode = table.buckets[i];
		while (householdNode != nullptr)
		{
			ResidentNode* residentNode = householdNode->household->residentHead;
			while (residentNode != nullptr)
			{
				if (residentNode->data.residentID == residentID)
				{
					return householdNode->household;
				}
				residentNode = residentNode->next;
			}
			householdNode = householdNode->next;
		}
	}

	return nullptr;
}

bool removeHouseholdFromHashTable(HouseholdHashTable& table, const std::string& householdID)
{
	int bucketIndex = hashHouseholdID(householdID);
	HouseholdHashNode* current = table.buckets[bucketIndex];
	HouseholdHashNode* previous = nullptr;

	while (current != nullptr)
	{
		if (current->key == householdID)
		{
			if (previous == nullptr)
			{
				table.buckets[bucketIndex] = current->next;
			}
			else
			{
				previous->next = current->next;
			}

			delete current;
			return true;
		}

		previous = current;
		current = current->next;
	}

	return false;
}

int countHouseholds(const HouseholdHashTable& table)
{
	int householdCount = 0;
	for (int i = 0; i < HOUSEHOLD_HASH_SIZE; ++i)
	{
		HouseholdHashNode* current = table.buckets[i];
		while (current != nullptr)
		{
			++householdCount;
			current = current->next;
		}
	}

	return householdCount;
}

int copyHouseholdPointers(const HouseholdHashTable& table, Household* householdPointers[], int capacity)
{
	if (householdPointers == nullptr || capacity <= 0)
	{
		return 0;
	}

	int copiedCount = 0;
	for (int i = 0; i < HOUSEHOLD_HASH_SIZE && copiedCount < capacity; ++i)
	{
		HouseholdHashNode* current = table.buckets[i];
		while (current != nullptr && copiedCount < capacity)
		{
			householdPointers[copiedCount] = current->household;
			++copiedCount;
			current = current->next;
		}
	}

	return copiedCount;
}

Household** createTemporaryHouseholdPointerArray(const HouseholdHashTable& table, int& householdCount)
{
	householdCount = countHouseholds(table);
	if (householdCount == 0)
	{
		return nullptr;
	}

	Household** householdPointers = new Household*[householdCount];
	int copiedCount = copyHouseholdPointers(table, householdPointers, householdCount);
	if (copiedCount != householdCount)
	{
		delete[] householdPointers;
		householdCount = 0;
		return nullptr;
	}

	return householdPointers;
}

void deleteTemporaryHouseholdPointerArray(Household** householdPointers)
{
	delete[] householdPointers;
}

void sortHouseholdPointers(Household* householdPointers[], int householdCount)
{
	for (int i = 0; i < householdCount - 1; ++i)
	{
		int smallestIndex = i;
		for (int j = i + 1; j < householdCount; ++j)
		{
			if (householdPointers[j]->householdID < householdPointers[smallestIndex]->householdID)
			{
				smallestIndex = j;
			}
		}

		if (smallestIndex != i)
		{
			Household* temporaryPointer = householdPointers[i];
			householdPointers[i] = householdPointers[smallestIndex];
			householdPointers[smallestIndex] = temporaryPointer;
		}
	}
}

Household* binarySearchHouseholds(Household* householdPointers[], int householdCount, const std::string& householdID)
{
	int left = 0;
	int right = householdCount - 1;

	while (left <= right)
	{
		int middle = left + (right - left) / 2;
		if (householdPointers[middle]->householdID == householdID)
		{
			return householdPointers[middle];
		}

		if (householdPointers[middle]->householdID < householdID)
		{
			left = middle + 1;
		}
		else
		{
			right = middle - 1;
		}
	}

	return nullptr;
}

void displayHouseholdsInHashOrder(const HouseholdHashTable& table)
{
	std::cout << "Households in hash-table traversal order:\n";
	for (int i = 0; i < HOUSEHOLD_HASH_SIZE; ++i)
	{
		HouseholdHashNode* current = table.buckets[i];
		while (current != nullptr)
		{
			std::cout << "  " << current->household->householdID
				<< " - " << current->household->address << "\n";
			current = current->next;
		}
	}
}

void displayOrderedHouseholdReport(const HouseholdHashTable& table)
{
	int householdCount = 0;
	Household** householdPointers = createTemporaryHouseholdPointerArray(table, householdCount);
	if (householdPointers == nullptr)
	{
		std::cout << "No households available.\n";
		return;
	}

	sortHouseholdPointers(householdPointers, householdCount);
	std::cout << "Households in ordered report:\n";
	for (int i = 0; i < householdCount; ++i)
	{
		std::cout << "  " << householdPointers[i]->householdID
			<< " - " << householdPointers[i]->address << "\n";
	}

	deleteTemporaryHouseholdPointerArray(householdPointers);
}

void destroyHouseholdHashTable(HouseholdHashTable& table)
{
	for (int i = 0; i < HOUSEHOLD_HASH_SIZE; ++i)
	{
		HouseholdHashNode* current = table.buckets[i];
		while (current != nullptr)
		{
			HouseholdHashNode* nextNode = current->next;
			delete current;
			current = nextNode;
		}
		table.buckets[i] = nullptr;
	}
}
