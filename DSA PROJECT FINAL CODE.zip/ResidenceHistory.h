#pragma once

#include <string>

struct ResidenceHistoryNode
{
	std::string householdID;
	std::string startDate;
	std::string endDate;
	std::string notes;

	ResidenceHistoryNode* next;
};

void appendResidenceHistory(
	ResidenceHistoryNode*& head,
	ResidenceHistoryNode*& tail,
	const std::string& householdID,
	const std::string& startDate,
	const std::string& endDate,
	const std::string& notes);

void displayResidenceHistory(const ResidenceHistoryNode* head);
void clearResidenceHistory(ResidenceHistoryNode*& head, ResidenceHistoryNode*& tail);
