#include "ResidentHashTable.h"

void initializeResidentHashTable(ResidentHashTable& table)
{
	for (int i = 0; i < RESIDENT_HASH_SIZE; ++i)
	{
		table.buckets[i] = nullptr;
	}
}

int hashResidentID(const std::string& key)
{
	int characterSum = 0;
	for (int i = 0; i < static_cast<int>(key.length()); ++i)
	{
		characterSum += static_cast<unsigned char>(key[i]);
	}

	return characterSum % RESIDENT_HASH_SIZE;
}

bool insertResident(ResidentHashTable& table, ResidentNode* residentNode)
{
	if (residentNode == nullptr || findResidentByID(table, residentNode->data.residentID) != nullptr)
	{
		return false;
	}

	int bucketIndex = hashResidentID(residentNode->data.residentID);
	ResidentHashNode* newNode = new ResidentHashNode;
	newNode->key = residentNode->data.residentID;
	newNode->residentNode = residentNode;
	newNode->next = table.buckets[bucketIndex];
	table.buckets[bucketIndex] = newNode;
	return true;
}

ResidentNode* findResidentByID(const ResidentHashTable& table, const std::string& residentID)
{
	int bucketIndex = hashResidentID(residentID);
	ResidentHashNode* current = table.buckets[bucketIndex];
	while (current != nullptr)
	{
		if (current->key == residentID)
		{
			return current->residentNode;
		}
		current = current->next;
	}

	return nullptr;
}

bool removeResidentFromHashTable(ResidentHashTable& table, const std::string& residentID)
{
	int bucketIndex = hashResidentID(residentID);
	ResidentHashNode* current = table.buckets[bucketIndex];
	ResidentHashNode* previous = nullptr;

	while (current != nullptr)
	{
		if (current->key == residentID)
		{
			if (previous == nullptr)
			{
				table.buckets[bucketIndex] = current->next;
			}
			else
			{
				previous->next = current->next;
			}

			delete current;
			return true;
		}

		previous = current;
		current = current->next;
	}

	return false;
}

void destroyResidentHashTable(ResidentHashTable& table)
{
	for (int i = 0; i < RESIDENT_HASH_SIZE; ++i)
	{
		ResidentHashNode* current = table.buckets[i];
		while (current != nullptr)
		{
			ResidentHashNode* nextNode = current->next;
			delete current;
			current = nextNode;
		}
		table.buckets[i] = nullptr;
	}
}
