#pragma once

#include <string>

struct RelationshipNode
{
	std::string relatedResidentID;
	std::string relationshipType;
	RelationshipNode* next;
};

struct FamilyGraphNode
{
	std::string residentID;
	RelationshipNode* relationshipHead;
	FamilyGraphNode* next;
};

struct FamilyGraph
{
	FamilyGraphNode* head;
};

void initializeFamilyGraph(FamilyGraph& graph);
FamilyGraphNode* findFamilyGraphNode(FamilyGraph& graph, const std::string& residentID);
bool addResidentVertex(FamilyGraph& graph, const std::string& residentID);
bool removeResidentVertex(FamilyGraph& graph, const std::string& residentID);
bool relationshipExists(const FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType);
bool addRelationship(FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType, bool bidirectional);
bool removeRelationship(FamilyGraph& graph, const std::string& fromResidentID, const std::string& toResidentID, const std::string& relationshipType, bool bidirectional);
void displayRelationships(const FamilyGraph& graph, const std::string& residentID);
void displayFamilyGraph(const FamilyGraph& graph);
int dfs(FamilyGraph& graph, const std::string& startResidentID, std::string visitedResidentIDs[], int maxVisited);
void displayDFS(FamilyGraph& graph, const std::string& startResidentID);
void destroyFamilyGraph(FamilyGraph& graph);
