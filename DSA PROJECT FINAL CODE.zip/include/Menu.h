#pragma once

#include "../AdministrativeAreas.h"
#include "../HouseholdHashTable.h"
#include "../ResidentHashTable.h"
#include "FamilyGraph.h"
#include "Persistence.h"

struct Application
{
	AdministrativeSystem administrativeSystem;
	HouseholdHashTable householdTable;
	ResidentHashTable residentTable;
	FamilyGraph familyGraph;
	bool sampleDataLoaded;
};

void initializeApplication(Application& application);
void destroyApplication(Application& application);
void runApplication();
