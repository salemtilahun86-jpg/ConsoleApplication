#pragma once

struct Application;

bool loadSampleData(Application& application);
bool runIntegrationTest();
