#pragma once

#include "../HouseholdHashTable.h"
#include "../ResidentHashTable.h"
#include "FamilyGraph.h"

bool saveToTextFile(const char* fileName, const HouseholdHashTable& householdTable, const FamilyGraph& graph);
bool loadFromTextFile(const char* fileName, HouseholdHashTable& householdTable, ResidentHashTable& residentTable, FamilyGraph& graph);
void clearApplicationData(HouseholdHashTable& householdTable, ResidentHashTable& residentTable, FamilyGraph& graph);
