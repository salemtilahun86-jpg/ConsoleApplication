#pragma once

#include <string>
#include "Constants.h"
#include "Resident.h"

struct ResidentHashNode
{
	std::string key;
	ResidentNode* residentNode;
	ResidentHashNode* next;
};

struct ResidentHashTable
{
	ResidentHashNode* buckets[RESIDENT_HASH_SIZE];
};

void initializeResidentHashTable(ResidentHashTable& table);
int hashResidentID(const std::string& key);
bool insertResident(ResidentHashTable& table, ResidentNode* residentNode);
ResidentNode* findResidentByID(const ResidentHashTable& table, const std::string& residentID);
bool removeResidentFromHashTable(ResidentHashTable& table, const std::string& residentID);
void destroyResidentHashTable(ResidentHashTable& table);
