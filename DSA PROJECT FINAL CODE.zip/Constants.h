#pragma once

const int MAX_CITIES = 20;
const int MAX_SUBCITIES = 50;
const int MAX_WOREDAS = 100;
const int MAX_CIVIL_EVENTS = 20;
const int MAX_DOCUMENTS = 20;
const int HOUSEHOLD_HASH_SIZE = 101;
const int RESIDENT_HASH_SIZE = 101;
