#include "Household.h"
#include <iostream>

namespace
{
void linkNodeAtBeginning(Household& household, ResidentNode* node)
{
	node->prev = nullptr;
	node->next = household.residentHead;

	if (household.residentHead == nullptr)
	{
		household.residentTail = node;
	}
	else
	{
		household.residentHead->prev = node;
	}

	household.residentHead = node;
	++household.residentCount;
}

void linkNodeAtEnd(Household& household, ResidentNode* node)
{
	node->next = nullptr;
	node->prev = household.residentTail;

	if (household.residentTail == nullptr)
	{
		household.residentHead = node;
	}
	else
	{
		household.residentTail->next = node;
	}

	household.residentTail = node;
	++household.residentCount;
}

void unlinkNode(Household& household, ResidentNode* node)
{
	if (node->prev != nullptr)
	{
		node->prev->next = node->next;
	}
	else
	{
		household.residentHead = node->next;
	}

	if (node->next != nullptr)
	{
		node->next->prev = node->prev;
	}
	else
	{
		household.residentTail = node->prev;
	}

	node->prev = nullptr;
	node->next = nullptr;
	--household.residentCount;
}

bool canAddResident(const Household& household, const ResidentHashTable& residentTable, const std::string& residentID)
{
	const ResidentNode* current = household.residentHead;
	while (current != nullptr)
	{
		if (current->data.residentID == residentID)
		{
			return false;
		}
		current = current->next;
	}

	return findResidentByID(residentTable, residentID) == nullptr;
}

bool addResidentNode(Household& household, ResidentHashTable& residentTable, ResidentNode* node, bool insertAtBeginning)
{
	if (insertAtBeginning)
	{
		linkNodeAtBeginning(household, node);
	}
	else
	{
		linkNodeAtEnd(household, node);
	}

	if (!insertResident(residentTable, node))
	{
		unlinkNode(household, node);
		clearResidentHistory(node->data);
		delete node;
		return false;
	}

	return true;
}

ResidentNode* mergeResidentLists(ResidentNode* first, ResidentNode* second)
{
	ResidentNode* mergedHead = nullptr;
	ResidentNode* mergedTail = nullptr;

	while (first != nullptr || second != nullptr)
	{
		ResidentNode* selectedNode;
		if (second == nullptr || (first != nullptr && first->data.fullName <= second->data.fullName))
		{
			selectedNode = first;
			first = first->next;
		}
		else
		{
			selectedNode = second;
			second = second->next;
		}

		selectedNode->prev = mergedTail;
		selectedNode->next = nullptr;
		if (mergedTail == nullptr)
		{
			mergedHead = selectedNode;
		}
		else
		{
			mergedTail->next = selectedNode;
		}
		mergedTail = selectedNode;
	}

	return mergedHead;
}

ResidentNode* mergeSortList(ResidentNode* head)
{
	if (head == nullptr || head->next == nullptr)
	{
		if (head != nullptr)
		{
			head->prev = nullptr;
		}
		return head;
	}

	ResidentNode* slow = head;
	ResidentNode* fast = head;
	while (fast->next != nullptr && fast->next->next != nullptr)
	{
		slow = slow->next;
		fast = fast->next->next;
	}

	ResidentNode* secondHalf = slow->next;
	slow->next = nullptr;
	if (secondHalf != nullptr)
	{
		secondHalf->prev = nullptr;
	}

	ResidentNode* firstSorted = mergeSortList(head);
	ResidentNode* secondSorted = mergeSortList(secondHalf);
	return mergeResidentLists(firstSorted, secondSorted);
}
}

void initializeHousehold(Household& household, const std::string& householdID, const std::string& cityID, const std::string& subCityID, const std::string& woredaID, const std::string& address)
{
	household.householdID = householdID;
	household.cityID = cityID;
	household.subCityID = subCityID;
	household.woredaID = woredaID;
	household.address = address;
	household.residentHead = nullptr;
	household.residentTail = nullptr;
	household.residentCount = 0;
	household.eventCount = 0;
	household.documentCount = 0;
}

bool addResidentToBeginning(Household& household, ResidentHashTable& residentTable, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender)
{
	if (!canAddResident(household, residentTable, residentID))
	{
		return false;
	}

	ResidentNode* newNode = createResidentNode(residentID, fullName, dateOfBirth, gender);
	return addResidentNode(household, residentTable, newNode, true);
}

bool addResidentToEnd(Household& household, ResidentHashTable& residentTable, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender)
{
	if (!canAddResident(household, residentTable, residentID))
	{
		return false;
	}

	ResidentNode* newNode = createResidentNode(residentID, fullName, dateOfBirth, gender);
	return addResidentNode(household, residentTable, newNode, false);
}

bool addResident(Household& household, ResidentHashTable& residentTable, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender)
{
	return addResidentToEnd(household, residentTable, residentID, fullName, dateOfBirth, gender);
}

ResidentNode* findResident(Household& household, const std::string& residentID)
{
	ResidentNode* current = household.residentHead;
	while (current != nullptr)
	{
		if (current->data.residentID == residentID)
		{
			return current;
		}
		current = current->next;
	}
	return nullptr;
}

ResidentNode* findResidentByName(Household& household, const std::string& fullName)
{
	ResidentNode* current = household.residentHead;
	while (current != nullptr)
	{
		if (current->data.fullName == fullName)
		{
			return current;
		}
		current = current->next;
	}
	return nullptr;
}


bool removeResident(Household& household, ResidentHashTable& residentTable, const std::string& residentID)

{
	ResidentNode* node = findResident(household, residentID);
	ResidentNode* hashNode = findResidentByID(residentTable, residentID);
	if (node == nullptr || hashNode != node)
	{
		return false;
	}

	if (!removeResidentFromHashTable(residentTable, residentID))
	{
		return false;
	}

	unlinkNode(household, node);
	clearResidentHistory(node->data);
	delete node;
	return true;
}

bool detachResidentNode(Household& household, const std::string& residentID, ResidentNode*& detachedNode)
{
	detachedNode = findResident(household, residentID);
	if (detachedNode == nullptr)
	{
		return false;
	}

	unlinkNode(household, detachedNode);
	return true;
}

bool attachExistingResidentNode(Household& household, ResidentNode* residentNode)
{
	if (residentNode == nullptr || findResident(household, residentNode->data.residentID) != nullptr)
	{
		return false;
	}

	linkNodeAtEnd(household, residentNode);
	return true;
}

void displayResidents(const Household& household)
{
	std::cout << "Residents in household " << household.householdID << ":\n";
	const ResidentNode* current = household.residentHead;
	while (current != nullptr)
	{
		std::cout << "  " << current->data.residentID << " - "
			<< current->data.fullName << ", DOB: "
			<< current->data.dateOfBirth << ", Gender: "
			<< current->data.gender << "\n";
		current = current->next;
	}
}

void displayResidentsBackward(const Household& household)
{
	std::cout << "Residents in household " << household.householdID << " (backward):\n";
	const ResidentNode* current = household.residentTail;
	while (current != nullptr)
	{
		std::cout << "  " << current->data.residentID << " - "
			<< current->data.fullName << ", DOB: "
			<< current->data.dateOfBirth << ", Gender: "
			<< current->data.gender << "\n";
		current = current->prev;
	}
}

void clearHouseholdResidents(Household& household, ResidentHashTable& residentTable)
{
	while (household.residentHead != nullptr)
	{
		ResidentNode* node = household.residentHead;
		removeResidentFromHashTable(residentTable, node->data.residentID);
		unlinkNode(household, node);
		clearResidentHistory(node->data);
		delete node;
	}

	household.residentHead = nullptr;
	household.residentTail = nullptr;
	household.residentCount = 0;
}

void mergeSortResidents(Household& household)
{
	household.residentHead = mergeSortList(household.residentHead);
	household.residentTail = household.residentHead;

	if (household.residentHead == nullptr)
	{
		return;
	}

	household.residentHead->prev = nullptr;
	while (household.residentTail->next != nullptr)
	{
		household.residentTail = household.residentTail->next;
	}
	household.residentTail->next = nullptr;
}
