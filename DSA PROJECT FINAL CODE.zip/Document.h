#pragma once

#include <string>

struct Document
{
	std::string documentID;
	std::string documentType;
	std::string issueDate;
	std::string status;
};
