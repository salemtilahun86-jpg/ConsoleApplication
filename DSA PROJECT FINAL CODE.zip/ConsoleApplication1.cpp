#include <cstdlib>
#include <fstream>
#include <iostream>
#include "AdministrativeAreas.h"
#include "Household.h"
#include "HouseholdHashTable.h"
#include "include/FamilyGraph.h"
#include "include/Menu.h"
#include "include/Persistence.h"

void requireCondition(bool condition, const char* message)
{
	if (!condition)
	{
		std::cerr << "Test failed: " << message << "\n";
		std::exit(1);
	}
}

void verifyListLinks(const Household& household, ResidentNode* expectedNodes[], int expectedCount)
{
	if (expectedCount == 0)
	{
		requireCondition(household.residentHead == nullptr, "empty list must have a null head");
		requireCondition(household.residentTail == nullptr, "empty list must have a null tail");
		requireCondition(household.residentCount == 0, "empty list must have a zero count");
		return;
	}

	requireCondition(household.residentHead == expectedNodes[0], "unexpected list head");
	requireCondition(household.residentTail == expectedNodes[expectedCount - 1], "unexpected list tail");
	requireCondition(household.residentCount == expectedCount, "unexpected resident count");

	ResidentNode* current = household.residentHead;
	for (int i = 0; i < expectedCount; ++i)
	{
		requireCondition(current == expectedNodes[i], "forward traversal has an unexpected node");
		ResidentNode* expectedPrevious = i == 0 ? nullptr : expectedNodes[i - 1];
		ResidentNode* expectedNext = i == expectedCount - 1 ? nullptr : expectedNodes[i + 1];
		requireCondition(current->prev == expectedPrevious, "incorrect prev link");
		requireCondition(current->next == expectedNext, "incorrect next link");
		current = current->next;
	}
	requireCondition(current == nullptr, "forward traversal did not end at null");

	current = household.residentTail;
	for (int i = expectedCount - 1; i >= 0; --i)
	{
		requireCondition(current == expectedNodes[i], "backward traversal has an unexpected node");
		current = current->prev;
	}
	requireCondition(current == nullptr, "backward traversal did not end at null");
}

void verifyHashTableIsEmpty(const ResidentHashTable& table)
{
	for (int i = 0; i < RESIDENT_HASH_SIZE; ++i)
	{
		requireCondition(table.buckets[i] == nullptr, "hash table should be empty after cleanup");
	}
}

void testAdministrativeSystem()
{
	AdministrativeSystem administrativeSystem;
	initializeAdministrativeSystem(administrativeSystem);

	addCity(administrativeSystem, "C001", "Addis Ababa");
	addSubCity(administrativeSystem, "SC001", "Bole", "C001");
	addSubCity(administrativeSystem, "SC002", "Yeka", "C001");
	addSubCity(administrativeSystem, "SC003", "Kirkos", "C001");
	addSubCity(administrativeSystem, "SC004", "Lemi Kura", "C001");
	addWoreda(administrativeSystem, "W001", "Woreda 03", "SC001");
	addWoreda(administrativeSystem, "W002", "Woreda 08", "SC001");
	addWoreda(administrativeSystem, "W003", "Woreda 05", "SC002");
	addWoreda(administrativeSystem, "W004", "Woreda 02", "SC003");
	addWoreda(administrativeSystem, "W005", "Woreda 04", "SC004");

	requireCondition(administrativeSystem.cityCount == 1, "incorrect city count");
	requireCondition(administrativeSystem.subCityCount == 4, "incorrect sub-city count");
	requireCondition(administrativeSystem.woredaCount == 5, "incorrect woreda count");
	requireCondition(findCity(administrativeSystem, "C001") != nullptr, "city search failed");
	requireCondition(findSubCity(administrativeSystem, "SC003") != nullptr, "sub-city search failed");
	requireCondition(findWoreda(administrativeSystem, "W005") != nullptr, "woreda search failed");
	requireCondition(findWoreda(administrativeSystem, "W999") == nullptr, "missing woreda search should fail");

	std::cout << "Fictional Addis Ababa administrative data:\n";
	displayAdministrativeSystem(administrativeSystem);
}

void testAddisAbabaHouseholds()
{
	ResidentHashTable residentTable;
	initializeResidentHashTable(residentTable);

	Household householdOne;
	initializeHousehold(householdOne, "H001", "C001", "SC001", "W001", "Kebele 03, House 124");
	requireCondition(addResident(householdOne, residentTable, "R001", "Abebe Bekele", "1998-04-12", "Male"), "R001 insertion failed");
	requireCondition(addResident(householdOne, residentTable, "R002", "Hana Abebe", "2000-08-21", "Female"), "R002 insertion failed");
	requireCondition(addResident(householdOne, residentTable, "R003", "Liya Abebe", "2022-02-15", "Female"), "R003 insertion failed");

	ResidentNode* residentOne = findResident(householdOne, "R001");
	requireCondition(residentOne != nullptr, "R001 list search failed");
	appendResidenceHistory(residentOne->data.historyHead, residentOne->data.historyTail, "H001", "2020-01-15", "2024-06-30", "Previous residence");
	appendResidenceHistory(residentOne->data.historyHead, residentOne->data.historyTail, "H003", "2024-07-01", "Present", "Transferred to current household");

	Household householdTwo;
	initializeHousehold(householdTwo, "H002", "C001", "SC001", "W002", "Kebele 07, House 218");
	requireCondition(addResident(householdTwo, residentTable, "R004", "Dawit Tesfaye", "1995-11-03", "Male"), "R004 insertion failed");
	requireCondition(addResident(householdTwo, residentTable, "R005", "Mekdes Dawit", "1997-06-18", "Female"), "R005 insertion failed");
	ResidentNode* residentFour = findResident(householdTwo, "R004");
	requireCondition(residentFour != nullptr, "R004 list search failed");
	appendResidenceHistory(residentFour->data.historyHead, residentFour->data.historyTail, "H002", "2019-03-01", "Present", "Current residence");

	Household householdThree;
	initializeHousehold(householdThree, "H003", "C001", "SC002", "W003", "Kebele 05, House 091");
	requireCondition(addResident(householdThree, residentTable, "R006", "Samuel Girma", "1992-01-27", "Male"), "R006 insertion failed");
	requireCondition(addResident(householdThree, residentTable, "R007", "Selamawit Samuel", "1994-09-10", "Female"), "R007 insertion failed");

	Household householdFour;
	initializeHousehold(householdFour, "H004", "C001", "SC003", "W004", "Kebele 02, House 157");
	requireCondition(addResident(householdFour, residentTable, "R008", "Bethlehem Tadesse", "2001-03-05", "Female"), "R008 insertion failed");

	Household householdFive;
	initializeHousehold(householdFive, "H005", "C001", "SC004", "W005", "Kebele 04, House 306");
	requireCondition(addResident(householdFive, residentTable, "R009", "Yonas Alemu", "1989-12-14", "Male"), "R009 insertion failed");
	requireCondition(addResident(householdFive, residentTable, "R010", "Rahel Yonas", "1991-07-22", "Female"), "R010 insertion failed");

	std::cout << "\nFictional Addis Ababa household sample:\n";
	displayResidents(householdOne);
	displayResidentsBackward(householdOne);
	std::cout << "Residence history for " << residentOne->data.fullName << ":\n";
	displayResidenceHistory(residentOne->data.historyHead);
	displayResidents(householdTwo);
	displayResidents(householdThree);
	displayResidents(householdFour);
	displayResidents(householdFive);

	requireCondition(findResidentByID(residentTable, "R010") != nullptr, "global resident hash lookup failed");

	clearHouseholdResidents(householdOne, residentTable);
	clearHouseholdResidents(householdTwo, residentTable);
	clearHouseholdResidents(householdThree, residentTable);
	clearHouseholdResidents(householdFour, residentTable);
	clearHouseholdResidents(householdFive, residentTable);
	verifyHashTableIsEmpty(residentTable);
	destroyResidentHashTable(residentTable);
}

void testResidentListOperations()
{
	ResidentHashTable residentTable;
	initializeResidentHashTable(residentTable);
	Household household;
	initializeHousehold(household, "HLIST", "C001", "SC001", "W001", "List Test Address");

	mergeSortResidents(household);
	verifyListLinks(household, nullptr, 0);
	requireCondition(findResident(household, "MISSING") == nullptr, "empty ID search should fail");
	requireCondition(findResidentByName(household, "Missing Resident") == nullptr, "empty name search should fail");
	requireCondition(!removeResident(household, residentTable, "MISSING"), "removing a missing resident should fail");

	Household otherHousehold;
	initializeHousehold(otherHousehold, "HOTHER", "C001", "SC001", "W001", "Other Test Address");
	requireCondition(addResident(otherHousehold, residentTable, "DUP-ID", "First Duplicate ID", "1990-01-01", "Male"), "initial global ID insertion failed");
	requireCondition(!addResident(household, residentTable, "DUP-ID", "Second Duplicate ID", "1990-01-01", "Female"), "duplicate global resident ID was accepted");
	clearHouseholdResidents(otherHousehold, residentTable);

	requireCondition(addResident(household, residentTable, "RL002", "Middle Resident", "1990-01-01", "Male"), "insertion into empty list failed");
	ResidentNode* middleNode = findResident(household, "RL002");
	requireCondition(household.residentHead == middleNode && household.residentTail == middleNode, "one-node head/tail state is invalid");
	requireCondition(addResidentToBeginning(household, residentTable, "RL001", "First Resident", "1991-01-01", "Female"), "beginning insertion failed");
	requireCondition(addResidentToEnd(household, residentTable, "RL003", "Last Resident", "1992-01-01", "Female"), "end insertion failed");

	ResidentNode* firstNode = findResident(household, "RL001");
	ResidentNode* lastNode = findResident(household, "RL003");
	ResidentNode* expectedNodes[3] = { firstNode, middleNode, lastNode };
	verifyListLinks(household, expectedNodes, 3);
	requireCondition(findResidentByName(household, "Middle Resident") == middleNode, "name search failed");
	requireCondition(findResidentByName(household, "Missing Resident") == nullptr, "missing name search should fail");
	displayResidents(household);
	displayResidentsBackward(household);

	requireCondition(removeResident(household, residentTable, "RL001"), "head removal failed");
	ResidentNode* remainingNodes[2] = { middleNode, lastNode };
	verifyListLinks(household, remainingNodes, 2);
	requireCondition(addResidentToEnd(household, residentTable, "RL004", "Fourth Resident", "1993-01-01", "Male"), "second end insertion failed");
	ResidentNode* fourthNode = findResident(household, "RL004");
	ResidentNode* fourNodes[3] = { middleNode, lastNode, fourthNode };
	verifyListLinks(household, fourNodes, 3);
	requireCondition(removeResident(household, residentTable, "RL003"), "middle removal failed");
	ResidentNode* afterMiddleRemoval[2] = { middleNode, fourthNode };
	verifyListLinks(household, afterMiddleRemoval, 2);
	requireCondition(removeResident(household, residentTable, "RL004"), "tail removal failed");
	ResidentNode* onlyNode[1] = { middleNode };
	verifyListLinks(household, onlyNode, 1);
	requireCondition(removeResident(household, residentTable, "RL002"), "only-node removal failed");
	verifyListLinks(household, nullptr, 0);
	requireCondition(!removeResident(household, residentTable, "RL002"), "removed resident should not be found");

	clearHouseholdResidents(household, residentTable);
	verifyHashTableIsEmpty(residentTable);
	destroyResidentHashTable(residentTable);
}

void testMergeSort()
{
	ResidentHashTable residentTable;
	initializeResidentHashTable(residentTable);
	Household household;
	initializeHousehold(household, "HTEST", "C001", "SC001", "W001", "Merge Sort Test Address");

	requireCondition(addResident(household, residentTable, "RTEST01", "Zewdu Kebede", "1990-05-11", "Male"), "RTEST01 insertion failed");
	requireCondition(addResident(household, residentTable, "RTEST02", "Abebe Bekele", "1998-04-12", "Male"), "RTEST02 insertion failed");
	requireCondition(addResident(household, residentTable, "RTEST03", "Hana Tesfaye", "2000-08-21", "Female"), "RTEST03 insertion failed");
	requireCondition(addResident(household, residentTable, "RTEST04", "Dawit Alemu", "1995-11-03", "Male"), "RTEST04 insertion failed");

	ResidentNode* originalNodes[4] =
	{
		findResidentByID(residentTable, "RTEST01"),
		findResidentByID(residentTable, "RTEST02"),
		findResidentByID(residentTable, "RTEST03"),
		findResidentByID(residentTable, "RTEST04")
	};
	std::cout << "\nHTEST before Merge Sort:\n";
	displayResidents(household);
	displayResidentsBackward(household);

	mergeSortResidents(household);

	ResidentNode* sortedNodes[4] =
	{
		originalNodes[1],
		originalNodes[3],
		originalNodes[2],
		originalNodes[0]
	};
	verifyListLinks(household, sortedNodes, 4);
	requireCondition(originalNodes[0]->data.residentID == "RTEST01", "resident data moved between nodes");
	requireCondition(originalNodes[1]->data.residentID == "RTEST02", "resident data moved between nodes");
	requireCondition(originalNodes[2]->data.residentID == "RTEST03", "resident data moved between nodes");
	requireCondition(originalNodes[3]->data.residentID == "RTEST04", "resident data moved between nodes");
	requireCondition(findResidentByID(residentTable, "RTEST01") == originalNodes[0], "RTEST01 hash pointer changed after sorting");
	requireCondition(findResidentByID(residentTable, "RTEST02") == originalNodes[1], "RTEST02 hash pointer changed after sorting");
	requireCondition(findResidentByID(residentTable, "RTEST03") == originalNodes[2], "RTEST03 hash pointer changed after sorting");
	requireCondition(findResidentByID(residentTable, "RTEST04") == originalNodes[3], "RTEST04 hash pointer changed after sorting");

	std::cout << "HTEST after Merge Sort:\n";
	displayResidents(household);
	displayResidentsBackward(household);
	std::cout << "ResidentNode address and ResidentHashTable pointer preservation: verified\n";

	clearHouseholdResidents(household, residentTable);
	verifyHashTableIsEmpty(residentTable);
	destroyResidentHashTable(residentTable);
}

void testAdditionalMergeSortCases()
{
	ResidentHashTable emptyTable;
	initializeResidentHashTable(emptyTable);
	Household emptyHousehold;
	initializeHousehold(emptyHousehold, "HEMPTY", "C001", "SC001", "W001", "Empty Test Address");
	mergeSortResidents(emptyHousehold);
	verifyListLinks(emptyHousehold, nullptr, 0);
	clearHouseholdResidents(emptyHousehold, emptyTable);
	destroyResidentHashTable(emptyTable);

	ResidentHashTable oneTable;
	initializeResidentHashTable(oneTable);
	Household oneHousehold;
	initializeHousehold(oneHousehold, "HONE", "C001", "SC001", "W001", "One Test Address");
	requireCondition(addResident(oneHousehold, oneTable, "ONE", "Only Resident", "1990-01-01", "Male"), "one-resident insertion failed");
	ResidentNode* oneNode = findResidentByID(oneTable, "ONE");
	mergeSortResidents(oneHousehold);
	ResidentNode* oneExpected[1] = { oneNode };
	verifyListLinks(oneHousehold, oneExpected, 1);
	requireCondition(findResidentByID(oneTable, "ONE") == oneNode, "one-resident hash pointer changed");
	clearHouseholdResidents(oneHousehold, oneTable);
	destroyResidentHashTable(oneTable);

	ResidentHashTable sortedTable;
	initializeResidentHashTable(sortedTable);
	Household sortedHousehold;
	initializeHousehold(sortedHousehold, "HSORTED", "C001", "SC001", "W001", "Sorted Test Address");
	requireCondition(addResident(sortedHousehold, sortedTable, "S1", "A Resident", "1990-01-01", "Male"), "sorted test insertion failed");
	requireCondition(addResident(sortedHousehold, sortedTable, "S2", "B Resident", "1990-01-01", "Female"), "sorted test insertion failed");
	requireCondition(addResident(sortedHousehold, sortedTable, "S3", "C Resident", "1990-01-01", "Male"), "sorted test insertion failed");
	ResidentNode* sortedExpected[3] =
	{
		findResidentByID(sortedTable, "S1"),
		findResidentByID(sortedTable, "S2"),
		findResidentByID(sortedTable, "S3")
	};
	mergeSortResidents(sortedHousehold);
	verifyListLinks(sortedHousehold, sortedExpected, 3);
	clearHouseholdResidents(sortedHousehold, sortedTable);
	destroyResidentHashTable(sortedTable);

	ResidentHashTable reverseTable;
	initializeResidentHashTable(reverseTable);
	Household reverseHousehold;
	initializeHousehold(reverseHousehold, "HREVERSE", "C001", "SC001", "W001", "Reverse Test Address");
	requireCondition(addResident(reverseHousehold, reverseTable, "V1", "C Resident", "1990-01-01", "Male"), "reverse test insertion failed");
	requireCondition(addResident(reverseHousehold, reverseTable, "V2", "B Resident", "1990-01-01", "Female"), "reverse test insertion failed");
	requireCondition(addResident(reverseHousehold, reverseTable, "V3", "A Resident", "1990-01-01", "Male"), "reverse test insertion failed");
	ResidentNode* reverseExpected[3] =
	{
		findResidentByID(reverseTable, "V3"),
		findResidentByID(reverseTable, "V2"),
		findResidentByID(reverseTable, "V1")
	};
	mergeSortResidents(reverseHousehold);
	verifyListLinks(reverseHousehold, reverseExpected, 3);
	clearHouseholdResidents(reverseHousehold, reverseTable);
	destroyResidentHashTable(reverseTable);

	ResidentHashTable duplicateTable;
	initializeResidentHashTable(duplicateTable);
	Household duplicateHousehold;
	initializeHousehold(duplicateHousehold, "HDUPLICATE", "C001", "SC001", "W001", "Duplicate Test Address");
	requireCondition(addResident(duplicateHousehold, duplicateTable, "D1", "Equal Name", "1990-01-01", "Male"), "duplicate-name insertion failed");
	requireCondition(addResident(duplicateHousehold, duplicateTable, "D2", "Equal Name", "1990-01-01", "Female"), "duplicate-name insertion failed");
	ResidentNode* duplicateExpected[2] =
	{
		findResidentByID(duplicateTable, "D1"),
		findResidentByID(duplicateTable, "D2")
	};
	mergeSortResidents(duplicateHousehold);
	verifyListLinks(duplicateHousehold, duplicateExpected, 2);
	clearHouseholdResidents(duplicateHousehold, duplicateTable);
	destroyResidentHashTable(duplicateTable);
}

void testHashCollisionHandling()
{
	ResidentHashTable residentTable;
	initializeResidentHashTable(residentTable);
	Household household;
	initializeHousehold(household, "HCOLLISION", "C001", "SC001", "W001", "Collision Test Address");

	requireCondition(hashResidentID("COLL-A") == hashResidentID("COLL-Ae"), "collision test IDs do not share a bucket");
	requireCondition(addResident(household, residentTable, "COLL-A", "Collision Alpha", "1990-01-01", "Male"), "first collision resident insertion failed");
	requireCondition(addResident(household, residentTable, "COLL-Ae", "Collision Alpha Extended", "1990-01-01", "Female"), "second collision resident insertion failed");

	int bucketIndex = hashResidentID("COLL-A");
	int chainLength = 0;
	ResidentHashNode* current = residentTable.buckets[bucketIndex];
	while (current != nullptr)
	{
		++chainLength;
		current = current->next;
	}
	requireCondition(chainLength == 2, "separate-chaining collision was not stored in one bucket");
	ResidentNode* secondResident = findResidentByID(residentTable, "COLL-Ae");
	requireCondition(findResidentByID(residentTable, "COLL-A") != nullptr, "first collision resident lookup failed");
	requireCondition(secondResident != nullptr, "second collision resident lookup failed");
	requireCondition(removeResident(household, residentTable, "COLL-A"), "first collision resident removal failed");
	requireCondition(findResidentByID(residentTable, "COLL-A") == nullptr, "removed collision resident is still present");
	requireCondition(findResidentByID(residentTable, "COLL-Ae") == secondResident, "remaining collision chain entry was damaged");
	requireCondition(removeResident(household, residentTable, "COLL-Ae"), "second collision resident removal failed");
	requireCondition(findResidentByID(residentTable, "COLL-Ae") == nullptr, "second collision resident is still present");

	clearHouseholdResidents(household, residentTable);
	verifyHashTableIsEmpty(residentTable);
	destroyResidentHashTable(residentTable);
	std::cout << "Separate-chaining collision handling: verified\n";
}

void deleteOwnedHousehold(HouseholdHashTable& householdTable, ResidentHashTable& residentTable, Household*& household)
{
	if (household == nullptr)
	{
		return;
	}

	clearHouseholdResidents(*household, residentTable);
	requireCondition(removeHouseholdFromHashTable(householdTable, household->householdID), "household hash entry removal failed during cleanup");
	delete household;
	household = nullptr;
}

bool pointerArrayContains(Household* householdPointers[], int householdCount, Household* expectedHousehold)
{
	for (int i = 0; i < householdCount; ++i)
	{
		if (householdPointers[i] == expectedHousehold)
		{
			return true;
		}
	}

	return false;
}

void testHouseholdHashTable()
{
	HouseholdHashTable householdTable;
	initializeHouseholdHashTable(householdTable);
	ResidentHashTable residentTable;
	initializeResidentHashTable(residentTable);
	requireCondition(countHouseholds(householdTable) == 0, "new household hash table should be empty");

	Household* householdOne = new Household;
	initializeHousehold(*householdOne, "H001", "C001", "SC001", "W001", "Kebele 03, House 124");
	requireCondition(addResident(*householdOne, residentTable, "R001", "Abebe Bekele", "1998-04-12", "Male"), "H001 resident insertion failed");
	requireCondition(addResident(*householdOne, residentTable, "R002", "Hana Abebe", "2000-08-21", "Female"), "H001 resident insertion failed");
	requireCondition(addResident(*householdOne, residentTable, "R003", "Liya Abebe", "2022-02-15", "Female"), "H001 resident insertion failed");

	Household* householdTwo = new Household;
	initializeHousehold(*householdTwo, "H002", "C001", "SC001", "W002", "Kebele 07, House 218");
	requireCondition(addResident(*householdTwo, residentTable, "R004", "Dawit Tesfaye", "1995-11-03", "Male"), "H002 resident insertion failed");
	requireCondition(addResident(*householdTwo, residentTable, "R005", "Mekdes Dawit", "1997-06-18", "Female"), "H002 resident insertion failed");

	Household* householdThree = new Household;
	initializeHousehold(*householdThree, "H003", "C001", "SC002", "W003", "Kebele 05, House 091");
	requireCondition(addResident(*householdThree, residentTable, "R006", "Samuel Girma", "1992-01-27", "Male"), "H003 resident insertion failed");
	requireCondition(addResident(*householdThree, residentTable, "R007", "Selamawit Samuel", "1994-09-10", "Female"), "H003 resident insertion failed");

	Household* householdFour = new Household;
	initializeHousehold(*householdFour, "H004", "C001", "SC003", "W004", "Kebele 02, House 157");
	requireCondition(addResident(*householdFour, residentTable, "R008", "Bethlehem Tadesse", "2001-03-05", "Female"), "H004 resident insertion failed");

	Household* householdFive = new Household;
	initializeHousehold(*householdFive, "H005", "C001", "SC004", "W005", "Kebele 04, House 306");
	requireCondition(addResident(*householdFive, residentTable, "R009", "Yonas Alemu", "1989-12-14", "Male"), "H005 resident insertion failed");
	requireCondition(addResident(*householdFive, residentTable, "R010", "Rahel Yonas", "1991-07-22", "Female"), "H005 resident insertion failed");

	// Insert in a non-sorted order so the report must sort a separate temporary array.
	requireCondition(insertHousehold(householdTable, householdThree), "H003 insertion failed");
	requireCondition(insertHousehold(householdTable, householdFive), "H005 insertion failed");
	requireCondition(insertHousehold(householdTable, householdOne), "H001 insertion failed");
	requireCondition(insertHousehold(householdTable, householdFour), "H004 insertion failed");
	requireCondition(insertHousehold(householdTable, householdTwo), "H002 insertion failed");
	requireCondition(countHouseholds(householdTable) == 5, "multiple household insertion count is incorrect");

	Household* duplicateHousehold = new Household;
	initializeHousehold(*duplicateHousehold, "H003", "C001", "SC002", "W003", "Duplicate Test Address");
	requireCondition(!insertHousehold(householdTable, duplicateHousehold), "duplicate household ID was accepted");
	delete duplicateHousehold;

	requireCondition(findHouseholdByID(householdTable, "H001") == householdOne, "H001 lookup returned the wrong pointer");
	requireCondition(findHouseholdByID(householdTable, "H003") == householdThree, "H003 lookup returned the wrong pointer");
	requireCondition(findHouseholdByID(householdTable, "H999") == nullptr, "missing household lookup should fail");
	displayHouseholdsInHashOrder(householdTable);

	Household* traversedHouseholds[5];
	int traversedCount = copyHouseholdPointers(householdTable, traversedHouseholds, 5);
	requireCondition(traversedCount == 5, "household traversal count is incorrect");
	requireCondition(pointerArrayContains(traversedHouseholds, traversedCount, householdOne), "traversal missed H001");
	requireCondition(pointerArrayContains(traversedHouseholds, traversedCount, householdTwo), "traversal missed H002");
	requireCondition(pointerArrayContains(traversedHouseholds, traversedCount, householdThree), "traversal missed H003");
	requireCondition(pointerArrayContains(traversedHouseholds, traversedCount, householdFour), "traversal missed H004");
	requireCondition(pointerArrayContains(traversedHouseholds, traversedCount, householdFive), "traversal missed H005");

	int temporaryCount = 0;
	Household** temporaryHouseholds = createTemporaryHouseholdPointerArray(householdTable, temporaryCount);
	requireCondition(temporaryHouseholds != nullptr, "temporary household pointer array was not created");
	requireCondition(temporaryCount == 5, "temporary household pointer array count is incorrect");
	sortHouseholdPointers(temporaryHouseholds, temporaryCount);
	requireCondition(temporaryHouseholds[0] == householdOne, "ordered report did not place H001 first");
	requireCondition(temporaryHouseholds[1] == householdTwo, "ordered report did not place H002 second");
	requireCondition(temporaryHouseholds[2] == householdThree, "ordered report did not place H003 third");
	requireCondition(temporaryHouseholds[3] == householdFour, "ordered report did not place H004 fourth");
	requireCondition(temporaryHouseholds[4] == householdFive, "ordered report did not place H005 fifth");

	requireCondition(binarySearchHouseholds(temporaryHouseholds, temporaryCount, "H003") == householdThree, "Binary Search did not find H003");
	requireCondition(binarySearchHouseholds(temporaryHouseholds, temporaryCount, "H999") == nullptr, "Binary Search found a missing household");
	deleteTemporaryHouseholdPointerArray(temporaryHouseholds);

	// The temporary array was deleted, but the original hash-table objects remain valid.
	requireCondition(findHouseholdByID(householdTable, "H003") == householdThree, "temporary array affected the household hash table");
	requireCondition(findResident(*householdThree, "R006") != nullptr, "household object was affected by temporary-array deletion");

	displayOrderedHouseholdReport(householdTable);

	// H005 is the only household in its bucket; removing the hash entry does not delete the object.
	requireCondition(removeHouseholdFromHashTable(householdTable, "H005"), "single-entry household removal failed");
	requireCondition(findHouseholdByID(householdTable, "H005") == nullptr, "removed household is still in the table");
	requireCondition(householdFive->householdID == "H005", "hash-table removal deleted the household object");
	requireCondition(findResident(*householdFive, "R009") != nullptr, "hash-table removal damaged the household residents");
	requireCondition(insertHousehold(householdTable, householdFive), "re-inserting the existing H005 object failed");
	requireCondition(!removeHouseholdFromHashTable(householdTable, "H999"), "removing a missing household should fail");

	Household* collisionOne = new Household;
	Household* collisionTwo = new Household;
	Household* collisionThree = new Household;
	initializeHousehold(*collisionOne, "HC-A", "C001", "SC001", "W001", "Collision House A");
	initializeHousehold(*collisionTwo, "HC-Ae", "C001", "SC001", "W001", "Collision House B");
	initializeHousehold(*collisionThree, "HC-Aee", "C001", "SC001", "W001", "Collision House C");
	requireCondition(hashHouseholdID("HC-A") == hashHouseholdID("HC-Ae"), "first household collision pair does not share a bucket");
	requireCondition(hashHouseholdID("HC-A") == hashHouseholdID("HC-Aee"), "second household collision pair does not share a bucket");
	requireCondition(insertHousehold(householdTable, collisionOne), "first collision household insertion failed");
	requireCondition(insertHousehold(householdTable, collisionTwo), "second collision household insertion failed");
	requireCondition(insertHousehold(householdTable, collisionThree), "third collision household insertion failed");

	int collisionBucket = hashHouseholdID("HC-A");
	int collisionChainLength = 0;
	HouseholdHashNode* collisionNode = householdTable.buckets[collisionBucket];
	while (collisionNode != nullptr)
	{
		++collisionChainLength;
		collisionNode = collisionNode->next;
	}
	requireCondition(collisionChainLength == 3, "household collision chain length is incorrect");
	requireCondition(findHouseholdByID(householdTable, "HC-A") == collisionOne, "first collision household lookup failed");
	requireCondition(findHouseholdByID(householdTable, "HC-Ae") == collisionTwo, "middle collision household lookup failed");
	requireCondition(findHouseholdByID(householdTable, "HC-Aee") == collisionThree, "last collision household lookup failed");

	requireCondition(removeHouseholdFromHashTable(householdTable, "HC-Ae"), "middle collision household removal failed");
	requireCondition(findHouseholdByID(householdTable, "HC-A") == collisionOne, "first collision household was damaged");
	requireCondition(findHouseholdByID(householdTable, "HC-Aee") == collisionThree, "last collision household was damaged");
	requireCondition(removeHouseholdFromHashTable(householdTable, "HC-Aee"), "first collision-chain entry removal failed");
	requireCondition(findHouseholdByID(householdTable, "HC-A") == collisionOne, "remaining collision household was damaged");
	requireCondition(removeHouseholdFromHashTable(householdTable, "HC-A"), "last collision-chain entry removal failed");
	requireCondition(householdTable.buckets[collisionBucket] == nullptr, "collision bucket was not emptied");

	delete collisionOne;
	delete collisionTwo;
	delete collisionThree;

	deleteOwnedHousehold(householdTable, residentTable, householdOne);
	deleteOwnedHousehold(householdTable, residentTable, householdTwo);
	deleteOwnedHousehold(householdTable, residentTable, householdThree);
	deleteOwnedHousehold(householdTable, residentTable, householdFour);
	deleteOwnedHousehold(householdTable, residentTable, householdFive);
	requireCondition(countHouseholds(householdTable) == 0, "household hash table is not empty after cleanup");
	verifyHashTableIsEmpty(residentTable);
	destroyHouseholdHashTable(householdTable);
	destroyResidentHashTable(residentTable);
	std::cout << "HouseholdHashTable operations, ordered reporting, and Binary Search: verified\n";
}

bool stringArrayContains(const std::string values[], int valueCount, const std::string& value)
{
	for (int i = 0; i < valueCount; ++i)
	{
		if (values[i] == value)
		{
			return true;
		}
	}

	return false;
}

void testFamilyGraph()
{
	FamilyGraph graph;
	initializeFamilyGraph(graph);

	requireCondition(addResidentVertex(graph, "R001"), "R001 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R002"), "R002 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R003"), "R003 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R004"), "R004 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R005"), "R005 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R006"), "R006 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R007"), "R007 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R009"), "R009 graph vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R010"), "R010 graph vertex insertion failed");
	requireCondition(!addResidentVertex(graph, "R001"), "duplicate graph vertex was accepted");
	requireCondition(findFamilyGraphNode(graph, "R001") != nullptr, "graph vertex lookup failed");
	requireCondition(findFamilyGraphNode(graph, "R999") == nullptr, "missing graph vertex lookup should fail");

	// Spouse is represented in both directions; Parent is represented in the stated direction.
	requireCondition(addRelationship(graph, "R001", "R002", "Spouse", true), "R001/R002 spouse relationship failed");
	requireCondition(addRelationship(graph, "R001", "R003", "Parent", false), "R001/R003 parent relationship failed");
	requireCondition(addRelationship(graph, "R002", "R003", "Parent", false), "R002/R003 parent relationship failed");
	requireCondition(addRelationship(graph, "R004", "R005", "Spouse", true), "R004/R005 spouse relationship failed");
	requireCondition(addRelationship(graph, "R006", "R007", "Spouse", true), "R006/R007 spouse relationship failed");
	requireCondition(addRelationship(graph, "R009", "R010", "Spouse", true), "R009/R010 spouse relationship failed");
	requireCondition(!addRelationship(graph, "R001", "R002", "Spouse", true), "duplicate relationship was accepted");
	requireCondition(relationshipExists(graph, "R001", "R002", "Spouse"), "forward spouse relationship was not stored");
	requireCondition(relationshipExists(graph, "R002", "R001", "Spouse"), "reverse spouse relationship was not stored");
	requireCondition(relationshipExists(graph, "R001", "R003", "Parent"), "directed parent relationship was not stored");
	requireCondition(!relationshipExists(graph, "R003", "R001", "Parent"), "unexpected reverse parent relationship was stored");

	displayRelationships(graph, "R001");
	displayFamilyGraph(graph);

	std::string visitedResidents[9];
	int visitedCount = dfs(graph, "R001", visitedResidents, 9);
	requireCondition(visitedCount == 3, "DFS visited an incorrect number of reachable vertices");
	requireCondition(stringArrayContains(visitedResidents, visitedCount, "R001"), "DFS missed R001");
	requireCondition(stringArrayContains(visitedResidents, visitedCount, "R002"), "DFS missed R002");
	requireCondition(stringArrayContains(visitedResidents, visitedCount, "R003"), "DFS missed R003");
	requireCondition(!stringArrayContains(visitedResidents, visitedCount, "R004"), "DFS visited an unreachable vertex");

	requireCondition(removeRelationship(graph, "R001", "R003", "Parent", false), "directed relationship removal failed");
	requireCondition(!relationshipExists(graph, "R001", "R003", "Parent"), "removed directed relationship is still present");
	requireCondition(!removeRelationship(graph, "R001", "R003", "Parent", false), "removing a missing relationship should fail");
	requireCondition(removeRelationship(graph, "R001", "R002", "Spouse", true), "bidirectional relationship removal failed");
	requireCondition(!relationshipExists(graph, "R001", "R002", "Spouse"), "forward spouse relationship was not removed");
	requireCondition(!relationshipExists(graph, "R002", "R001", "Spouse"), "reverse spouse relationship was not removed");

	destroyFamilyGraph(graph);
	requireCondition(graph.head == nullptr, "graph head was not cleared");
	std::cout << "FamilyGraph adjacency lists, relationship rules, and DFS: verified\n";
}

void testPersistence()
{
	const char* fileName = "batch4_test_data.txt";
	HouseholdHashTable householdTable;
	ResidentHashTable residentTable;
	FamilyGraph graph;
	initializeHouseholdHashTable(householdTable);
	initializeResidentHashTable(residentTable);
	initializeFamilyGraph(graph);

	Household* householdOne = new Household;
	initializeHousehold(*householdOne, "H001", "C001", "SC001", "W001", "Kebele 03, House 124");
	requireCondition(addResident(*householdOne, residentTable, "R001", "Abebe Bekele", "1998-04-12", "Male"), "persistence R001 insertion failed");
	requireCondition(addResident(*householdOne, residentTable, "R002", "Hana Abebe", "2000-08-21", "Female"), "persistence R002 insertion failed");
	requireCondition(addResident(*householdOne, residentTable, "R003", "Liya Abebe", "2022-02-15", "Female"), "persistence R003 insertion failed");
	ResidentNode* residentOne = findResident(*householdOne, "R001");
	appendResidenceHistory(residentOne->data.historyHead, residentOne->data.historyTail, "H001", "2020-01-15", "2024-06-30", "Previous residence");
	appendResidenceHistory(residentOne->data.historyHead, residentOne->data.historyTail, "H003", "2024-07-01", "Present", "Transferred to current household");
	householdOne->events[0].eventID = "E001";
	householdOne->events[0].eventType = "Birth";
	householdOne->events[0].eventDate = "1998-04-12";
	householdOne->events[0].notes = "Birth registered";
	householdOne->eventCount = 1;
	householdOne->documents[0].documentID = "DOC001";
	householdOne->documents[0].documentType = "Birth Certificate";
	householdOne->documents[0].issueDate = "1998-04-20";
	householdOne->documents[0].status = "Verified";
	householdOne->documentCount = 1;

	Household* householdTwo = new Household;
	initializeHousehold(*householdTwo, "H002", "C001", "SC001", "W002", "Kebele 07, House 218");
	requireCondition(addResident(*householdTwo, residentTable, "R004", "Dawit Tesfaye", "1995-11-03", "Male"), "persistence R004 insertion failed");
	requireCondition(addResident(*householdTwo, residentTable, "R005", "Mekdes Dawit", "1997-06-18", "Female"), "persistence R005 insertion failed");

	requireCondition(insertHousehold(householdTable, householdOne), "persistence H001 insertion failed");
	requireCondition(insertHousehold(householdTable, householdTwo), "persistence H002 insertion failed");
	requireCondition(addResidentVertex(graph, "R001"), "persistence R001 vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R002"), "persistence R002 vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R003"), "persistence R003 vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R004"), "persistence R004 vertex insertion failed");
	requireCondition(addResidentVertex(graph, "R005"), "persistence R005 vertex insertion failed");
	requireCondition(addRelationship(graph, "R001", "R002", "Spouse", true), "persistence spouse relationship insertion failed");
	requireCondition(addRelationship(graph, "R001", "R003", "Parent", false), "persistence parent relationship insertion failed");
	requireCondition(addRelationship(graph, "R002", "R003", "Parent", false), "persistence second parent relationship insertion failed");
	requireCondition(addRelationship(graph, "R004", "R005", "Spouse", true), "persistence second spouse relationship insertion failed");

	requireCondition(saveToTextFile(fileName, householdTable, graph), "text persistence save failed");

	std::ifstream savedFile(fileName);
	requireCondition(savedFile.is_open(), "saved text file could not be opened");
	bool foundHouseholdMarker = false;
	bool foundResidentMarker = false;
	bool foundHistoryMarker = false;
	bool foundEventMarker = false;
	bool foundDocumentMarker = false;
	bool foundRelationMarker = false;
	std::string line;
	while (std::getline(savedFile, line))
	{
		if (line.find("HOUSEHOLD|H001") == 0)
		{
			foundHouseholdMarker = true;
		}
		if (line.find("RESIDENT|R001") == 0)
		{
			foundResidentMarker = true;
		}
		if (line.find("HISTORY|") == 0)
		{
			foundHistoryMarker = true;
		}
		if (line.find("EVENT|") == 0)
		{
			foundEventMarker = true;
		}
		if (line.find("DOCUMENT|") == 0)
		{
			foundDocumentMarker = true;
		}
		if (line.find("RELATION|") == 0)
		{
			foundRelationMarker = true;
		}
		requireCondition(line.find("0x") == std::string::npos, "saved file contains a raw memory address");
	}
	savedFile.close();
	requireCondition(foundHouseholdMarker, "saved file is missing a household marker");
	requireCondition(foundResidentMarker, "saved file is missing a resident marker");
	requireCondition(foundHistoryMarker, "saved file is missing a history marker");
	requireCondition(foundEventMarker, "saved file is missing an event marker");
	requireCondition(foundDocumentMarker, "saved file is missing a document marker");
	requireCondition(foundRelationMarker, "saved file is missing a relation marker");

	clearApplicationData(householdTable, residentTable, graph);
	requireCondition(countHouseholds(householdTable) == 0, "pre-load household cleanup failed");
	requireCondition(graph.head == nullptr, "pre-load graph cleanup failed");
	verifyHashTableIsEmpty(residentTable);

	requireCondition(loadFromTextFile(fileName, householdTable, residentTable, graph), "text persistence load failed");
	Household* loadedHouseholdOne = findHouseholdByID(householdTable, "H001");
	Household* loadedHouseholdTwo = findHouseholdByID(householdTable, "H002");
	requireCondition(loadedHouseholdOne != nullptr, "H001 was not reconstructed");
	requireCondition(loadedHouseholdTwo != nullptr, "H002 was not reconstructed");
	requireCondition(loadedHouseholdOne->residentCount == 3, "H001 resident count was not reconstructed");
	requireCondition(loadedHouseholdTwo->residentCount == 2, "H002 resident count was not reconstructed");

	ResidentNode* loadedResidentOne = findResidentByID(residentTable, "R001");
	requireCondition(loadedResidentOne == findResident(*loadedHouseholdOne, "R001"), "resident hash pointer does not reference the loaded list node");
	requireCondition(findResidentByID(residentTable, "R004") == findResident(*loadedHouseholdTwo, "R004"), "second resident hash pointer is invalid after load");
	requireCondition(loadedResidentOne != nullptr, "R001 was not reconstructed");
	requireCondition(loadedResidentOne->data.historyHead != nullptr, "R001 residence history was not reconstructed");
	requireCondition(loadedResidentOne->data.historyHead->householdID == "H001", "first history household was not reconstructed");
	requireCondition(loadedResidentOne->data.historyHead->next != nullptr, "second history record was not reconstructed");
	requireCondition(loadedHouseholdOne->eventCount == 1, "civil event count was not reconstructed");
	requireCondition(loadedHouseholdOne->events[0].eventType == "Birth", "civil event data was not reconstructed");
	requireCondition(loadedHouseholdOne->documentCount == 1, "document count was not reconstructed");
	requireCondition(loadedHouseholdOne->documents[0].documentID == "DOC001", "document data was not reconstructed");
	requireCondition(relationshipExists(graph, "R001", "R002", "Spouse"), "loaded spouse relationship is missing");
	requireCondition(relationshipExists(graph, "R002", "R001", "Spouse"), "loaded reverse spouse relationship is missing");
	requireCondition(relationshipExists(graph, "R001", "R003", "Parent"), "loaded parent relationship is missing");
	requireCondition(!relationshipExists(graph, "R003", "R001", "Parent"), "loaded parent relationship has an unexpected reverse");

	std::string visitedResidents[5];
	int visitedCount = dfs(graph, "R001", visitedResidents, 5);
	requireCondition(visitedCount == 3, "DFS after loading visited an incorrect number of vertices");
	requireCondition(stringArrayContains(visitedResidents, visitedCount, "R001"), "loaded DFS missed R001");
	requireCondition(stringArrayContains(visitedResidents, visitedCount, "R002"), "loaded DFS missed R002");
	requireCondition(stringArrayContains(visitedResidents, visitedCount, "R003"), "loaded DFS missed R003");

	ResidentNode* residentPointerBeforeGraphCleanup = findResidentByID(residentTable, "R001");
	destroyFamilyGraph(graph);
	requireCondition(findResidentByID(residentTable, "R001") == residentPointerBeforeGraphCleanup, "FamilyGraph cleanup affected a resident object");
	initializeFamilyGraph(graph);
	clearApplicationData(householdTable, residentTable, graph);
	requireCondition(countHouseholds(householdTable) == 0, "post-load household cleanup failed");
	verifyHashTableIsEmpty(residentTable);
	requireCondition(graph.head == nullptr, "post-load graph cleanup failed");
	std::cout << "Text save/load, reconstruction, DFS after loading, and ownership cleanup: verified\n";
}

int main()
{
	runApplication();
	return 0;
}
