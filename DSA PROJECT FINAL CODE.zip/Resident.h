#pragma once

#include <string>
#include "ResidenceHistory.h"

struct Resident
{
	std::string residentID;
	std::string fullName;
	std::string dateOfBirth;
	std::string gender;

	ResidenceHistoryNode* historyHead;
	ResidenceHistoryNode* historyTail;
};

struct ResidentNode
{
	Resident data;

	ResidentNode* prev;
	ResidentNode* next;
};

void initializeResident(Resident& resident, const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender);
ResidentNode* createResidentNode(const std::string& residentID, const std::string& fullName, const std::string& dateOfBirth, const std::string& gender);
void clearResidentHistory(Resident& resident);
