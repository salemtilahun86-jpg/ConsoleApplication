#include "AdministrativeAreas.h"
#include <iostream>

void initializeAdministrativeSystem(AdministrativeSystem& system)
{
	system.cityCount = 0;
	system.subCityCount = 0;
	system.woredaCount = 0;
}

bool addCity(AdministrativeSystem& system, const std::string& cityID, const std::string& name)
{
	if (system.cityCount >= MAX_CITIES || findCity(system, cityID) != nullptr)
	{
		return false;
	}

	system.cities[system.cityCount].cityID = cityID;
	system.cities[system.cityCount].name = name;
	++system.cityCount;
	return true;
}

bool addSubCity(AdministrativeSystem& system, const std::string& subCityID, const std::string& name, const std::string& cityID)
{
	if (system.subCityCount >= MAX_SUBCITIES || findSubCity(system, subCityID) != nullptr || findCity(system, cityID) == nullptr)
	{
		return false;
	}

	system.subCities[system.subCityCount].subCityID = subCityID;
	system.subCities[system.subCityCount].name = name;
	system.subCities[system.subCityCount].cityID = cityID;
	++system.subCityCount;
	return true;
}

bool addWoreda(AdministrativeSystem& system, const std::string& woredaID, const std::string& name, const std::string& subCityID)
{
	if (system.woredaCount >= MAX_WOREDAS || findWoreda(system, woredaID) != nullptr || findSubCity(system, subCityID) == nullptr)
	{
		return false;
	}

	system.woredas[system.woredaCount].woredaID = woredaID;
	system.woredas[system.woredaCount].name = name;
	system.woredas[system.woredaCount].subCityID = subCityID;
	++system.woredaCount;
	return true;
}

City* findCity(AdministrativeSystem& system, const std::string& cityID)
{
	for (int i = 0; i < system.cityCount; ++i)
	{
		if (system.cities[i].cityID == cityID)
		{
			return &system.cities[i];
		}
	}
	return nullptr;
}

SubCity* findSubCity(AdministrativeSystem& system, const std::string& subCityID)
{
	for (int i = 0; i < system.subCityCount; ++i)
	{
		if (system.subCities[i].subCityID == subCityID)
		{
			return &system.subCities[i];
		}
	}
	return nullptr;
}

Woreda* findWoreda(AdministrativeSystem& system, const std::string& woredaID)
{
	for (int i = 0; i < system.woredaCount; ++i)
	{
		if (system.woredas[i].woredaID == woredaID)
		{
			return &system.woredas[i];
		}
	}
	return nullptr;
}

void displayAdministrativeSystem(const AdministrativeSystem& system)
{
	std::cout << "Cities:\n";
	for (int i = 0; i < system.cityCount; ++i)
	{
		std::cout << "  " << system.cities[i].cityID << " - " << system.cities[i].name << "\n";
	}

	std::cout << "Sub-cities:\n";
	for (int i = 0; i < system.subCityCount; ++i)
	{
		std::cout << "  " << system.subCities[i].subCityID << " - " << system.subCities[i].name
			<< " (City: " << system.subCities[i].cityID << ")\n";
	}

	std::cout << "Woredas:\n";
	for (int i = 0; i < system.woredaCount; ++i)
	{
		std::cout << "  " << system.woredas[i].woredaID << " - " << system.woredas[i].name
			<< " (Sub-city: " << system.woredas[i].subCityID << ")\n";
	}
}
